# 技術HTML Agent Builder Knowledge不要版 v1.1.0

Microsoft 365 Copilot Agent BuilderでファイルをKnowledgeへアップロードできない環境向けの構成です。

- 作成Agentと監査Agentの中核ルールをInstructionsへ統合
- Knowledge欄は空のままで利用可能
- 対象資料は会話ごとに添付または貼り付け
- SharePoint Knowledgeが利用できる場合は任意で追加可能

最初に`QUICK_START_NO_KNOWLEDGE.md`を参照してください。
