# Validation Report

Package version: 1.0.0
Validation date: 2026-08-06

## Automated validation

PASS: Agent Builder package validation passed.

## Field limits

| Agent | Name chars / 30 | Description chars / 1000 | Instructions chars / 8000 | Knowledge / 20 | Starter prompts | Tests |
|---|---:|---:|---:|---:|---:|---:|
| technical-html-author | 10 | 129 | 2604 | 6 | 6 | 6 |
| technical-html-audit | 10 | 110 | 2533 | 6 | 6 | 6 |

## Migration checks

- PASS: Core behavior and hard gates are in Instructions, not only in Knowledge.
- PASS: All embedded Knowledge files use `.txt`.
- PASS: Both agents explicitly use Code Interpreter for file generation or static source analysis.
- PASS: Source-document prompt injection is treated as content, not control instruction.
- PASS: Original-file preservation is explicit.
- PASS: Browser, keyboard, screen-reader, and print checks are not falsely claimed when unexecuted.
- PASS: Six positive/edge cases are provided for each agent.

## Known limitations

- Agent Builder has no direct ZIP import for this package; fields must be copied into Configure.
- Code Interpreter static analysis is not equivalent to the original deterministic Python audit script.
- Playwright browser QA requires external execution or Copilot Studio Action.
- Final behavior must be verified in the tenant because licensing, policies, and model updates can affect capabilities.
