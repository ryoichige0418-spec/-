# Copilot Studio拡張：決定論的監査とブラウザQA

Agent Builderネイティブ版は、Code InterpreterによるHTMLソース静的解析と内容監査を行う。元Skillの`audit_html.py`と`browser_qa.py`をそのまま実行し、Playwrightスクリーンショットや機械判定を取得する場合は、AgentをCopilot Studioへコピーし、外部Actionを追加する。

## 推奨構成

```text
Microsoft 365 Copilot Agent
        ↓ Copy to Copilot Studio
Copilot Studio Agent
        ↓ Custom connector / Agent flow / MCP action
Azure Container Apps または Azure Functions
        ↓
audit_html.py + browser_qa.py + Playwright Chromium
        ↓
JSON監査結果 + スクリーンショットURL + 修正確認
```

## Action契約の例

### POST /v1/html-audit

入力：
- `html_text`：UTF-8 HTMLソース
- `base_url`：相対リンク解決用。任意
- `run_browser_qa`：boolean
- `viewports`：例 `[[320,800],[390,844],[768,1024],[1440,900]]`
- `strict`：warningも失敗扱いにするか

出力：
- `overall_status`
- `findings[]`：severity、rule_id、location、message、impact、fix
- `static_summary`
- `browser_summary`
- `screenshots[]`
- `unverified_items[]`

## セキュリティ

- HTMLを隔離コンテナで処理する。
- 外部通信を既定で遮断する。
- JavaScript実行を必要最小限にする。
- 処理時間、ファイルサイズ、URLスキームを制限する。
- 認証とテナント境界を設定する。
- HTML、スクリーンショット、ログの保持期間を定める。

## コピー後の注意

Agent BuilderからCopilot Studioへコピーすると、Name、Description、Instructions、Starter prompts、SharePoint、Websitesはコピー対象になる。埋込みファイルは再アップロードし、Code InterpreterはCopilot Studio側で再設定する必要がある。コピー後のAgentは元Agentと同期されない。

## 同梱ソース

`source-tools/`に元の次のスクリプトを保持している。
- `audit_html.py`
- `browser_qa.py`
- `scaffold_document.py`

このフォルダはAgent Builder Knowledgeへアップロードしない。
