# HTML監査Actionの実装契約

## 目的

Agent Builder版で未実施となる決定論的静的監査と実ブラウザQAを、Copilot Studio Actionから呼び出すための境界を定義する。

## 必須入力

- HTMLソースまたはアクセス制御済み一時URL
- 実行モード：static_only / static_and_browser
- ビューポート一覧
- JavaScript許可方針

## 必須出力

- 合否
- 規則ID付きの指摘
- 重大度
- DOMまたは行番号の対象位置
- 読者・技術判断への影響
- 修正方針
- 再試験条件
- 実施済み／未実施項目
- スクリーンショット参照

## 非機能要件

- 一回の処理を短時間で終了させる。
- 外部URL、data URL、file URL、JavaScriptを明示的に制御する。
- プロセスとブラウザを要求ごとに隔離する。
- 原本を変更しない。
- 応答JSONのスキーマ版を返す。
- 監査規則版とブラウザ版を記録する。
