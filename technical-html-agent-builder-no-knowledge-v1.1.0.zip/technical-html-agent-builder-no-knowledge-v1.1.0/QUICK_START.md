# Agent Builder導入手順

## 1. 作成エージェント

1. Microsoft 365 Copilotを開く。
2. `New agent`→`Skip to configure`を選ぶ。
3. `agents/technical-html-author/name.txt`、`description.txt`、`instructions.txt`を各欄へ貼り付ける。
4. `agents/technical-html-author/knowledge/`内の6つのTXTをアップロードする。
5. `Create documents, charts, and code`をONにする。
6. `Create images`、People、Email、Teams、Search all websitesは既定ではOFFにする。
7. Default response modeを`Think deeper`にする。
8. `Only use specified sources`をONにする。
9. `starter_prompts.md`の6件を登録する。
10. `test_cases.md`をTry itで確認する。

## 2. 監査エージェント

1. 別の新規Agentを作る。
2. `agents/technical-html-audit/`のName、Description、Instructionsを貼り付ける。
3. 同フォルダの`knowledge/`内6ファイルをアップロードする。
4. Code Interpreter、Model、Knowledge settingsを作成エージェントと同様に設定する。
5. Starter promptsとテストケースを登録・実行する。

## 3. 実際の使用例

### 作成

```text
添付した技術レポートを基に、研究者とプロセス技術者向けの単一HTML資料を作成してください。
結論、主要因果、詳細根拠の三層構造とし、数式はMathML、重要図には代替説明を付けてください。
```

### 監査

HTMLファイルを直接扱えない場合：

```bash
python3 tools/prepare_html_for_agent_builder.py report.html
```

`report.html.txt`を監査エージェントへ添付し、次を依頼します。

```text
添付HTMLソースを総合監査してください。静的検査をCode Interpreterで実行し、
Blocker、Error、Warning、Noteで整理してください。実ブラウザ未確認項目は分離してください。
```

## 4. 共有前の確認

- Knowledgeに機密情報がない。
- 共有対象ユーザーがKnowledgeへアクセスしてよい。
- Try itの全テストが期待どおりである。
- エージェントが出典のない数値を作らない。
- HTML生成時にファイルを返す。
- 監査だけの依頼でファイルを変更しない。
- 実ブラウザ未実施を合格と表現しない。

## 5. SharePointを使う場合

HTMLはAgent Builderの端末埋込みKnowledgeではなく、SharePoint上の`.html`として参照できます。運用中に更新するテンプレートや用語辞書はSharePointへ置くと、権限と更新を一元管理できます。ただし、InstructionsをSharePointへ移して8,000文字制限を回避する使い方はしません。
