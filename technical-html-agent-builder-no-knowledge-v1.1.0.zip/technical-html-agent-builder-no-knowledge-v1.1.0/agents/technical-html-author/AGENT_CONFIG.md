# Agent Builder設定：技術HTML資料作成

## 用途

日本語科学技術HTMLの新規作成、再構成、改訂、ファイル生成を担当する。

## Configureタブへ入力する値

### Name

```text
技術HTML資料作成
```

### Description

```text
日本語の科学技術レポート、レクチャー資料、設計・解析手順、社内ナレッジを、認知負荷、根拠追跡、数式・図表、モバイル表示、アクセシビリティを考慮したHTMLとして設計・生成・改訂します。添付資料を基に、ダウンロード可能なHTMLファイルと検証結果を作成します。
```

### Instructions

`instructions.txt`の全文を貼り付ける。

- 文字数：2604 / 8,000
- InstructionsをKnowledgeへ分割しない。
- 貼り付け後に末尾まで保存されていることを確認する。

### Knowledge

次のTXTファイルをこのエージェントのKnowledgeへアップロードする。

- `knowledge/01_information_architecture.txt`
- `knowledge/02_japanese_technical_writing.txt`
- `knowledge/03_evidence_and_provenance.txt`
- `knowledge/04_equations_figures_tables.txt`
- `knowledge/05_html_accessibility_security.txt`
- `knowledge/06_html_template_reference.txt`

Knowledgeは背景知識、評価基準、例、テンプレートであり、挙動の中核はInstructionsにある。

### Capabilities

- **Create documents, charts, and code：ON**
- Create images：OFF（図解画像の生成も担わせる場合だけON）

### Model

- Default response mode：**Think deeper**

### Knowledge settings

- Only use specified sources：**ON**
- Search all websites：**OFF**
- Reference people in organization：**OFF**
- Email／Teams knowledge：**OFF**

`Only use specified sources`は一般モデル知識を完全遮断する機能ではないため、出典と未確認事項の扱いはInstructionsでも制御している。

### Starter Prompts

`starter_prompts.md`から登録する。

## 公開前確認

1. `test_cases.md`の全ケースをTry itで実行する。
2. 数値や出典を捏造しないことを確認する。
3. HTMLファイル生成または静的監査でCode Interpreterが呼ばれることを確認する。
4. 実ブラウザ未確認を合格と表現しないことを確認する。
5. 共有先ユーザーがKnowledgeへアクセスしてよいことを確認する。
