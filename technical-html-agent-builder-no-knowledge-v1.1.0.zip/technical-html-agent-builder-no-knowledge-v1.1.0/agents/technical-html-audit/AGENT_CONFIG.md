# Agent Builder設定：技術HTML品質監査

## 用途

完成HTMLの独立監査、重大度判定、修正優先順位、必要に応じた改訂版生成を担当する。

## Configureタブへ入力する値

### Name

```text
技術HTML品質監査
```

### Description

```text
日本語の科学技術HTML資料を、技術的追跡性、認知負荷、情報探索性、数式・図表、アクセシビリティ、モバイル表示、外部依存の観点から監査します。問題を重大度順に整理し、必要に応じて原本を保持した修正版HTMLを生成します。
```

### Instructions

`instructions.txt`の全文を貼り付ける。

- 文字数：2533 / 8,000
- InstructionsをKnowledgeへ分割しない。
- 貼り付け後に末尾まで保存されていることを確認する。

### Knowledge

次のTXTファイルをこのエージェントのKnowledgeへアップロードする。

- `knowledge/01_information_architecture.txt`
- `knowledge/02_evidence_and_provenance.txt`
- `knowledge/03_equations_figures_tables.txt`
- `knowledge/04_html_accessibility_security.txt`
- `knowledge/05_audit_rubric_and_gates.txt`
- `knowledge/06_reader_test_and_browser_qa.txt`

Knowledgeは背景知識、評価基準、例、テンプレートであり、挙動の中核はInstructionsにある。

### Capabilities

- **Create documents, charts, and code：ON**
- Create images：OFF（図解画像の生成も担わせる場合だけON）

### Model

- Default response mode：**Think deeper**

### Knowledge settings

- Only use specified sources：**ON**
- Search all websites：**OFF**
- Reference people in organization：**OFF**
- Email／Teams knowledge：**OFF**

`Only use specified sources`は一般モデル知識を完全遮断する機能ではないため、出典と未確認事項の扱いはInstructionsでも制御している。

### Starter Prompts

`starter_prompts.md`から登録する。

## 公開前確認

1. `test_cases.md`の全ケースをTry itで実行する。
2. 数値や出典を捏造しないことを確認する。
3. HTMLファイル生成または静的監査でCode Interpreterが呼ばれることを確認する。
4. 実ブラウザ未確認を合格と表現しないことを確認する。
5. 共有先ユーザーがKnowledgeへアクセスしてよいことを確認する。
