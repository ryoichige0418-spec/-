# 技術HTML品質監査 — Knowledge不要設定

- Name: `技術HTML品質監査`
- Description: `description.txt`を貼り付け
- Instructions: `instructions.txt`を全文貼り付け
- Knowledge: 空欄
- Create documents, charts, and code: 表示される場合はON
- Starter prompts: `starter_prompts.md`から登録
- Test: `test_cases.md`を使用

対象資料・HTMLは、恒久Knowledgeではなく各会話へ添付します。
