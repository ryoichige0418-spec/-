#!/usr/bin/env python3
"""Copy an UTF-8 HTML source file to a .txt file for Microsoft 365 Agent Builder input."""
from __future__ import annotations

import argparse
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input_html', type=Path)
    parser.add_argument('output_txt', type=Path, nargs='?')
    parser.add_argument('--force', action='store_true')
    args = parser.parse_args()

    src = args.input_html
    if not src.is_file():
        parser.error(f'Input file not found: {src}')
    dst = args.output_txt or src.with_suffix(src.suffix + '.txt')
    if dst.exists() and not args.force:
        parser.error(f'Output exists: {dst}. Use --force to replace it.')

    raw = src.read_bytes()
    try:
        text = raw.decode('utf-8-sig')
    except UnicodeDecodeError as exc:
        parser.error(f'Input is not UTF-8: {exc}')
    dst.write_text(text, encoding='utf-8', newline='\n')
    print(dst)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
