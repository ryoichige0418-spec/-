# Knowledgeファイルを使用できない環境での設定手順

## 方針

Agent BuilderのKnowledge欄は空のまま使用します。作成・監査に必要な中核ルールは、各`instructions.txt`へ統合済みです。

## 1. 技術HTML資料作成Agent

1. Agent Builderで新しいAgentを作成する。
2. Nameに`技術HTML資料作成`を入力する。
3. `agents/technical-html-author/description.txt`をDescriptionへ貼り付ける。
4. `agents/technical-html-author/instructions.txt`をInstructionsへ全文貼り付ける。
5. Knowledgeは追加しない。
6. `Create documents, charts, and code`が表示される場合はONにする。
7. `starter_prompts.md`からStarter promptsを登録する。
8. Try itで`test_cases.md`のテストを実行する。

## 2. 技術HTML品質監査Agent

1. 別の新しいAgentを作成する。
2. Nameに`技術HTML品質監査`を入力する。
3. `agents/technical-html-audit/description.txt`をDescriptionへ貼り付ける。
4. `agents/technical-html-audit/instructions.txt`をInstructionsへ全文貼り付ける。
5. Knowledgeは追加しない。
6. `Create documents, charts, and code`が表示される場合はONにする。
7. `starter_prompts.md`からStarter promptsを登録する。
8. Try itで`test_cases.md`のテストを実行する。

## 3. 資料の渡し方

Knowledgeへ恒久登録できないため、対象資料は各会話で添付または貼り付けます。

- Word、PDF、TXTなどを添付できる場合：会話へ直接添付する。
- HTMLを添付できない場合：HTMLソースをUTF-8のTXTへ変更して添付する。
- SharePointをKnowledgeに指定できる場合：共通テンプレートや用語集だけをSharePointへ置き、Agentから参照する。

## 4. 制約

Knowledgeなしでも作成規則と監査基準は維持されますが、次は会話ごとに与える必要があります。

- 組織固有の用語辞書
- 社内テンプレート
- 固有の出典・規格
- 過去資料

これらを恒久的に利用する必要がある場合は、SharePoint Knowledge、Copilot Studio、またはカスタム宣言型Agentへの移行を検討します。
