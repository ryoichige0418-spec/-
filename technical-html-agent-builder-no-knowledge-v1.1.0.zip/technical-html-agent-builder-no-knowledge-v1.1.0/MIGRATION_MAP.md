# 移植対応表

| 元Skill要素 | Agent Builderでの移植先 | 実装内容 |
|---|---|---|
| `technical-html-author/SKILL.md` | 作成AgentのInstructions | 作成ワークフロー、三層構造、主張分類、HTML要件、自己監査、ハードゲート |
| `technical-html-audit/SKILL.md` | 監査AgentのInstructions | 静的・内容監査、重大度、ハードゲート、修正順序、報告形式 |
| Author references | Author Knowledge TXT | 情報設計、日本語文章、根拠、数式・図表、HTML標準 |
| Audit references | Audit Knowledge TXT | 監査ルーブリック、重大度、読者テスト、ブラウザQA |
| HTML template／CSS | Author Knowledge＋`assets/` | Knowledge用TXTと再利用可能な原本ファイル |
| `scaffold_document.py` | Code Interpreter＋任意ローカルツール | Agent BuilderではCode InterpreterにHTMLファイルを生成させる |
| `audit_html.py` | Code Interpreter静的解析 | 決定論的スクリプト実行ではなく、Instructionsに検査項目を明記 |
| `browser_qa.py` | Agent Builderでは未実施扱い | 完全保持にはCopilot Studio Actionまたは外部CIが必要 |
| eval trigger queries | Starter prompts／Try it tests | 代表ユースケースと否定ケースへ変換 |
| `AGENTS.md` | 適用なし | Agent Builderでは各AgentのInstructionsが永続規則を担う |
| Skill frontmatter | Name／Description | 30文字・1,000文字制限へ適合 |

## 意図的に移植しなかったもの

- ローカル相対パスによるSkill参照
- シェルコマンドの自動実行
- Playwrightブラウザ起動
- Gitリポジトリ内のAGENTS.md継承

これらはAgent Builderの実行モデルと一致しないため、Code Interpreter、手動検証、Copilot Studio拡張へ分離した。
