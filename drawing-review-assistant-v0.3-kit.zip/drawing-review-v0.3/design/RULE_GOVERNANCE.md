# ルールの正文化と採用

## 3種類を混同しない
一般確認観点: 独自の検図手順。規格の完全な実装ではない。
原典資料: JIS規格票、社内標準、図面、研修資料。読み取り・検索しただけでは採用済みルールではない。
採用済み実行ルール: 要求、適用条件、例外、原典版・位置、検証方法、承認記録を持つ配布スナップショット。

## 推奨責任分担
ルール候補作成者と原典責任者/承認者を分ける。配布権限は管理者に限定する。判断が割れる規格解釈は根拠と未解決点を記録し、どちらかを自動採用しない。部品図の出図承認者はAIとは別に置く。

## 優先関係
「社内規則が常にJISより優先」「新しい文書が常に優先」という固定順位を使わない。製品・契約で採用する要求の集合、法令や安全条件、適用版、個別の例外承認を先に確認する。同時に有効な要求が競合する場合は保留し、権限者の判断へ送る。
例: プロジェクト指定の寸法指示と社内一般値が競合したら、上書き可否の根拠を示し、勝手に平均化・厳しい側採用をしない。

## 候補から配布まで
A. 資料収集: 版、効力、所有者、適用範囲、利用権限を確認。JIS無償閲覧サイトの本文をダウンロード・スクレイプして配布パックにしない。
B. 整理: 1要求1候補。must/recommendation/example/inferred、発効日、失効日、条件、例外、引用位置、原文を分ける。結合セルや図表の文脈を確認する。
C. 差分: 追加/変更/維持/削除候補、旧新原典の置換を明示。抽出で消えたものを自動廃止しない。
D. 検証: 適合例、違反例、対象外例、読取り不明例、境界値例の最低5種類を原典責任者が確認。
E. 承認: 原典責任者が内容と適用条件を承認。approved_by、approved_on、approval_recordを正式システムの実記録から転記する。AIに架空記入させない。
F. 配布: 管理者がcontent-boundなハッシュ付きスナップショットを作り、テスト後に検図スキルを差し替える。旧版を保持する。更新後に新規会話と別ユーザーで検証する。

## 管理者CLI
`tools/prepare_approval_request.py` はハッシュと候補IDを含む未承認のテンプレートだけを出す。正式承認の結果を記録し、採用しない候補をapproved_rulesから除く。

```sh
python tools/prepare_approval_request.py --catalog candidate-catalog.json --normative normative-evidence.json --out approval-request.json
python tools/build_release.py --daily-template skills/drawing-review-assistant --catalog candidate-catalog.json --normative normative-evidence.json --approvals approved-record.json --as-of YYYY-MM-DD --out approved-review-skill.zip
```

catalog_digest、normative_digest、rule_digest、evidence_digestは内容の一致を検証するためのチェックサム。電子署名や承認者認証ではない。ファイルとスキルの変更権限を持つ者はハッシュも書き換えられる。本人性と権限はEntra ID、管理リポジトリのACL、組織の承認フロー等で強制する。
未承認の候補が台帳に残っても、日常側のruntime_catalogはpendingにする。形式や文脈チェックでusableとなっただけでは採用されない。

## JIS根拠登録
`examples/normative-entry-template.json` を用い、source_file/source_sha256/版/追補/条項/位置/要求/適用条件/例外を正当な原典から整理する。rule_idsに対応する一般確認IDを結ぶ。content_kind=verified_requirement、rights_confirmed=trueは、管理者が実際に確認した後だけ設定する。
規格表を将来数値変換へ使う場合は、寸法区間の端点包含、単位、符号、表の見出し・注記まで機械化し、境界値試験を追加する。今回の計算器はH7等を規格表で自動展開する実装ではない。本文登録のみで自動公差表参照が有効になることはない。

## 社内資料の推奨格納
SharePoint等の管理ライブラリをRaw / Curated / Approved / Retired / Evaluationに分離する。Rawは原典権限を維持し、Curatedは候補、Approvedのみ実行対象。日常エージェントはApprovedの読み取り専用。原典の検索結果ではなく採用台帳を全件列挙してから適用条件を絞る。
固有情報を日常スキルへ埋め込む場合は、そのスキル利用者全員に開示してよい範囲だけにする。文書別ACLの維持が必要な情報は、スキル内にコピーせず認可付きの参照経路を使う。保存期間、監査ログ、削除方針、機密区分も配布前に決定する。
