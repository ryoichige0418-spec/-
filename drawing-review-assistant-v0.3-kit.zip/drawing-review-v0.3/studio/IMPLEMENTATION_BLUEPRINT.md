# Copilot Studioへの移行設計（未実装）
本ファイルは設計書。Power Platform Solution/Agent Flowの実体や外部サービスは同梱しない。

## 入口を混同しない
Agent Builder + Custom Skillsは本キットの初期導入先。Skills ZIPとStudioのSolution ZIPは別物。
StudioでファイルをKnowledgeへ登録する容量制限と、ユーザーが実行時に添付するファイル形式/容量は別。公開チャンネルによって添付の可否も異なる。
公式文書確認時点では通常のファイル入力はPDF/DOCX/CSV/TXT/画像等。XLSX/PPTXの会話入力は実験段階とされるため、前回Excelを添付して再検図する経路を本番前提で断定しない。承認済みストレージからファイルを取得するFlowや、管理されたJSON記録の参照経路を検証する。SharePoint公開チャネルではファイル入力が利用できない。

## 推奨Topicsと責務
Review.New: 認証ユーザー、原図添付、図番・版・対象範囲を確定。入力が既にある場合は重ねて質問しない。
Review.Focus: 対象ルール/ページを設定し、共通確認と未実施範囲を残す。
Review.Recheck: 前回review_idと原図を認可付き取得し、対応IDとハッシュを結び直す。
Review.Explain: 既存指摘と採用スナップショットの根拠を説明。判定を無承認で上書きしない。
Rule.Propose / Rule.Approve / Rule.Release: 管理者専用。候補作成、承認、配布を別操作にする。

## Agent Flows / サービス
GetApprovedRuleSnapshot(project, product, process, drawing_date): 承認版ID・全ルール一覧・原典参照を返す。使用者の権限とプロジェクト境界をサーバー側で検査する。
ExtractDrawing(file): 元ファイルID/ハッシュ、ページ数、原図画像の参照、抽出テキストを返す。文字抽出成功で全図確認済みにしない。
ValidateAndReview(observations, snapshot_id): スキーマ・適用条件・規格根拠・数値・未実施を決定的コードで検証。スナップショットはサーバー側で取得し、クライアント送信の承認JSONを無条件には信頼しない。
PersistReview(report): 承認されたストレージへ検図記録を保存。project/review_id/原図hash/ルール版を固定。認可・監査ログ・冪等性キーを確認。
ApproveRule(candidate_id, approver): 組織の承認者権限で実行し、承認イベントと内容ハッシュを保存。AIの自己承認は禁止。

ファイル変数は実添付のメタデータから取得し、AIが作ったcontentBytesやURLに置換しない。ファイル入力をツールに渡す際はCustom valueのPower Fxで渡し、Dynamically fill with AIに依存しない。

単一添付の形を示す例（複数の場合は選択又はループする）:
```powerfx
If(
  IsEmpty(System.Activity.Attachments),
  [],
  [{contentBytes: First(System.Activity.Attachments).Content,
    name: First(System.Activity.Attachments).Name}]
)
```
これは接続先が添付配列を要求する場合の形。File型やRecord型を要求するツールへそのまま渡さず、接続先契約に合わせる。複数ファイルを無言でFirstだけ処理しない。

## サーバー側で必須の制御
認証/認可、入力サイズ/形式/ZIP展開上限、マルウェア・外部参照の検査、原図と規則のプロンプト注入対策、正規化後のスキーマ検証、承認済み版固定、監査ログ、保管/削除、DLP、タイムアウト、重複実行防止。これらは本キットのSkill用Pythonだけでは完成しない。
JSONゲートを通さないLLM回答を正式レポートとして採用しない。Studioのオーケストレーションで判定確定前に検証ツールを必須実行し、検証サービスの結果と出力を結び付ける。

## API契約案
入力: review_id、authenticated_actor(サーバー取得)、project_id、drawing_file_ref、drawing_sha256、rule_snapshot_id、observations(schema3.0)、previous_review_id。
出力: result_state(success/partial/needs_input/rejected)、review_id、rule_snapshot_id、source_sha256、checks、findings、coverage、numeric、report_file_ref、warnings。
失敗しても曖昧なsuccessを返さず、確定できなかった範囲を明示。外部ファイル参照の権限失効は要確認とし、古いキャッシュで自動合格させない。

## 本番への移行順
まずSkillsで運用・誤指摘の傾向を検証。次に承認台帳と履歴を管理ストレージへ移し、検証処理を認証サービスにする。必要が出てからCAD属性/DXF/STEP解析やPLM連携を追加する。API連携を利用するためだけに初版から多数エージェントへ分割しない。
