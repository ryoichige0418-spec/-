"""Maintainer-only release assembly. Does not authenticate, approve, or deploy.

Run only after the organization's approval workflow has authorized the records.
The output is a complete Agent Builder daily-review skill ZIP, not a Studio solution.
"""
import argparse,json,shutil,sys,tempfile
from pathlib import Path


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--daily-template',required=True);p.add_argument('--catalog',required=True)
    p.add_argument('--normative',required=True);p.add_argument('--approvals',required=True)
    p.add_argument('--as-of',required=True);p.add_argument('--out',required=True)
    a=p.parse_args()
    template=Path(a.daily_template).resolve()
    sys.path.insert(0,str(template/'scripts'))
    from package_skill import package,digest
    from runtime_catalog import recompile,raw_candidate,get_normative_entry,approval_valid
    try:
        catalog=json.loads(Path(a.catalog).read_text(encoding='utf-8-sig'))
        normative=json.loads(Path(a.normative).read_text(encoding='utf-8-sig'))
        approvals=json.loads(Path(a.approvals).read_text(encoding='utf-8-sig'))
        if approvals.get('catalog_digest')!=digest(catalog) or approvals.get('normative_digest')!=digest(normative):
            raise ValueError('承認記録と配布する候補台帳・規格根拠のハッシュが一致しません。')
        if not approvals.get('release_id'):raise ValueError('正式なrelease_idが必要です。')
        if not approvals.get('approved_rules') and not approvals.get('normative_approvals'):
            raise ValueError('採用するルール又は規格条項の承認記録がありません。')
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)/'drawing-review-assistant'
            shutil.copytree(template,root,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
            for name,obj in [('rule-catalog.json',catalog),('normative-evidence.json',normative),('rule-approvals.json',approvals)]:
                (root/'references'/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            compiled=recompile(catalog,a.as_of,root=root)
            rules={r['rule_id']:r for r in compiled['rules']}
            for rec in approvals.get('approved_rules',[]):
                r=rules.get(rec.get('rule_id'))
                if not r or not r.get('release_approved') or r['status'] not in {'usable','advisory'}:
                    raise ValueError('承認対象に保留・参考・不一致のルールがあります。')
            for rec in approvals.get('normative_approvals',[]):
                get_normative_entry(rec['evidence_id'],root,a.as_of)
            result=package(root,a.out)
            result.update(release_id=approvals['release_id'],approval_authentication='組織の承認システムで別途実施',
                          deployed=False,pending_rules=sum(r['status']=='pending' for r in compiled['rules']))
        print(json.dumps(result,ensure_ascii=False,indent=2))
    except (ValueError,OSError,KeyError,TypeError) as exc:p.exit(2,'リリース作成エラー: '+str(exc)+'\n')

if __name__=='__main__':main()
