"""Produce content-bound but unsigned, unapproved human approval templates."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'skills/drawing-review-assistant/scripts'))
from package_skill import digest
from runtime_catalog import raw_candidate

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--catalog',required=True);p.add_argument('--normative',required=True);p.add_argument('--out',required=True)
    a=p.parse_args()
    try:
        c=json.loads(Path(a.catalog).read_text(encoding='utf-8-sig'));n=json.loads(Path(a.normative).read_text(encoding='utf-8-sig'))
        blank={'approved_by':None,'approved_on':None,'approval_record':None,'valid_until':None}
        output={'schema_version':'1.0','release_id':None,'catalog_digest':digest(c),'normative_digest':digest(n),
          'approved_rules':[{'rule_id':r['rule_id'],'rule_digest':digest(raw_candidate(r)),**blank} for r in c['rules'] if r['status'] in {'usable','advisory'}],
          'normative_approvals':[{'evidence_id':r['evidence_id'],'evidence_digest':digest(r),**blank} for r in n.get('entries',[])],
          'notice':'未承認テンプレート。採用しない候補を除き、正式承認の実記録だけを記入する。AIは自己承認しない。'}
        with Path(a.out).open('x',encoding='utf-8') as f:json.dump(output,f,ensure_ascii=False,indent=2)
        print('未承認のテンプレートを作成しました。')
    except (ValueError,OSError,KeyError,TypeError) as exc:p.exit(2,str(exc)+'\n')
if __name__=='__main__':main()
