"""Validate and package a local Copilot skill. Standard library only."""
import hashlib
import json
import re
import zipfile
from pathlib import Path


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def package(root, output):
    root, output = Path(root).resolve(), Path(output)
    files = []
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('シンボリックリンクはパッケージに含められません。')
        if not path.is_file() or '__pycache__' in path.parts or path.suffix == '.pyc':
            continue
        relative = path.relative_to(root)
        if path.suffix not in {'.md', '.py', '.json', '.txt'}:
            raise ValueError('未対応のパッケージファイル: ' + str(relative))
        if len(relative.parts) > 3 or path.stat().st_size > 25_000_000:
            raise ValueError('パッケージの深さ又はファイルサイズ上限を超えています。')
        files.append(path)
    if len(files) > 350:
        raise ValueError('ファイル数が350を超えています。')
    skill = (root / 'SKILL.md').read_text(encoding='utf-8')
    if len(skill) >= 20000 or not re.search(r'^name: [a-z0-9][a-z0-9-]*$', skill, re.M):
        raise ValueError('SKILL.mdの名称又は文字数が不正です。')
    for file in files:
        if file.suffix == '.md':
            for link in re.findall(r'\]\(([^)]+)\)', file.read_text(encoding='utf-8')):
                if '://' not in link and not (file.parent / link).is_file():
                    raise ValueError('参照ファイルがありません: ' + link)
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        handle = output.open('xb')
    except FileExistsError:
        raise ValueError('出力ZIPは既に存在します。別名で保存してください。') from None
    try:
        with handle, zipfile.ZipFile(handle, 'w', zipfile.ZIP_DEFLATED) as archive:
            for file in files:
                archive.write(file, file.relative_to(root).as_posix())
        if output.stat().st_size > 50_000_000:
            raise ValueError('ZIPが50MBを超えました。')
        with zipfile.ZipFile(output) as archive:
            if archive.testzip() is not None:
                raise ValueError('ZIPの整合性検査に失敗しました。')
    except Exception:
        output.unlink(missing_ok=True)
        raise
    return {'file_count': len(files), 'bytes': output.stat().st_size,
            'sha256': hashlib.sha256(output.read_bytes()).hexdigest()}
