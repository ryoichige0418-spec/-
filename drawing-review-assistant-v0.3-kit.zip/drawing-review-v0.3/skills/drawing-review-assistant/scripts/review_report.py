"""Mandatory v0.3 entry point: guarded review JSON -> one review workbook."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile
from xml.etree import ElementTree as ET
from runtime_catalog import ROOT
import guardrails
import report_core

read_xlsx=report_core.read_xlsx
write_xlsx=report_core.write_xlsx


def normalize(data,root=ROOT,previous=None):
    prepared,meta=guardrails.prepare(data,root,previous)
    return guardrails.finish(report_core.normalize(prepared,root,previous),meta)


def bind_file(data,path):
    path=Path(path)
    if not path.is_file():raise ValueError('原図ファイルがありません。')
    from inspect_input import inspect
    info=inspect(path)
    sha=info['sha256']
    if info['page_count'] is not None and data['drawing'].get('page_count')!=info['page_count']:
        raise ValueError('原図ファイルから取得したページ数と入力が一致しません。')
    old=data['drawing'].get('sha256')
    if old and old!=sha:raise ValueError('原図ファイルと入力SHA-256が一致しません。')
    # File display names are not trusted identifiers; digest is bound to bytes.
    data['drawing']['sha256']=sha
    if data.get('numeric_input') is not None:
        num=data['numeric_input']['drawing']
        for k in ('file','number','revision'):
            if num.get(k)!=data['drawing'].get(k):raise ValueError('数値入力が別の図面を参照しています。')
        if num.get('sha256') and num['sha256']!=sha:raise ValueError('数値入力の原図SHA-256が一致しません。')
        data['numeric_input']['drawing']=dict(data['drawing'])
    return data


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    subs=parser.add_subparsers(dest='command',required=True)
    create=subs.add_parser('create')
    create.add_argument('input');create.add_argument('--out',required=True)
    create.add_argument('--drawing-file',required=True,help='アップロードされた原図の実パス')
    create.add_argument('--previous');create.add_argument('--skill-root',default=str(ROOT))
    read=subs.add_parser('read');read.add_argument('input');read.add_argument('--out',required=True)
    args=parser.parse_args()
    try:
        if args.command=='read':
            result=read_xlsx(args.input)
            with Path(args.out).open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
            print(json.dumps({'drawing':result['drawing'],'findings':len(result['findings'])},ensure_ascii=False))
        else:
            previous=read_xlsx(args.previous) if args.previous else None
            data=bind_file(json.loads(Path(args.input).read_text(encoding='utf-8-sig')),args.drawing_file)
            result=normalize(data,args.skill_root,previous)
            write_xlsx(result,args.out)
            print(json.dumps({'file':args.out,'summary':result['summary'],'rule_set':result['rule_set']},ensure_ascii=False))
    except (ValueError,OSError,KeyError,TypeError,IndexError,AttributeError,StopIteration,ET.ParseError,zipfile.BadZipFile) as exc:
        parser.exit(2,'検図レポートエラー: '+str(exc)+'\n')

if __name__=='__main__':main()
