#!/usr/bin/env python3
"""Compile evidence-linked candidates into a Copilot skill and knowledge files.

Only validates recorded structure and internal consistency, not truth of source
transcription or semantic correctness. Uses Python standard library, no network.
"""
import argparse
import hashlib
import json
import re
import zipfile
from datetime import date
from pathlib import Path

VERSION = '0.1.0'
SLUG = re.compile(r'[a-z0-9]+(?:-[a-z0-9]+)*\Z')
ROLES = {'standard', 'training', 'drawing', 'example', 'unknown'}
STATES = {'current', 'draft', 'superseded', 'unknown'}
READ = {'clear', 'uncertain', 'unreadable'}
CLASSES = {'requirement', 'recommendation', 'example', 'inferred'}
LEVELS = {'company', 'product', 'process', 'project', 'drawing', 'unknown'}
STATUSES = {'usable', 'advisory', 'reference_only', 'pending'}


class BuildError(ValueError):
    pass


def text(obj, field, optional=False):
    value = obj.get(field)
    if optional and value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise BuildError(f'{field}: 空でない文字列が必要です。')
    if len(value) > 30000:
        raise BuildError(f'{field}: 長すぎます。分割してください。')
    return value.strip()


def objects(obj, field):
    values = obj.get(field)
    if not isinstance(values, list) or any(not isinstance(v, dict) for v in values):
        raise BuildError(f'{field}: オブジェクト配列が必要です。')
    if len(values) > 2000:
        raise BuildError(f'{field}: 2000件以下に分割してください。')
    return values


def strings(obj, field):
    values = obj.get(field)
    if not isinstance(values, list) or any(not isinstance(v, str) or not v.strip() for v in values):
        raise BuildError(f'{field}: 文字列配列が必要です。')
    return values


def choice(obj, field, choices):
    value = text(obj, field)
    if value not in choices:
        raise BuildError(f'{field}: 値 {value!r} は未対応です。')
    return value


def iso_date(value):
    if not isinstance(value, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
        raise BuildError('日付はYYYY-MM-DDで指定してください。')
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise BuildError('日付が不正です。') from exc


def normal(value):
    return ' '.join(value.split())


def rule_id(namespace, key):
    digest = hashlib.sha256((namespace + '\0' + key).encode()).hexdigest()[:12].upper()
    return 'CORP-' + digest


def validate_sources(manifest):
    index = {}
    for source in objects(manifest, 'sources'):
        sid = text(source, 'id')
        if sid in index:
            raise BuildError('資料IDが重複しています。')
        for field in ('file', 'title'):
            text(source, field)
        choice(source, 'role', ROLES)
        choice(source, 'state', STATES)
        choice(source, 'coverage', {'complete', 'partial', 'unreadable', 'unknown'})
        text(source, 'revision', optional=True)
        text(source, 'metadata_basis', optional=True)
        text(source, 'url', optional=True)
        for key in ('effective_from', 'effective_to'):
            if source.get(key) is not None:
                iso_date(source[key])
        if source.get('effective_from') and source.get('effective_to') and source['effective_from'] > source['effective_to']:
            raise BuildError('資料の有効期間が逆転しています。')
        strings(source, 'unread_parts')
        if 'file_aliases' in source:
            strings(source, 'file_aliases')
        segments = {}
        for segment in objects(source, 'segments'):
            bid = text(segment, 'id')
            if bid in segments:
                raise BuildError('資料内のセグメントIDが重複しています。')
            for key in ('locator', 'text'):
                text(segment, key)
            choice(segment, 'read_status', READ)
            choice(segment, 'channel', {'body', 'table', 'visual', 'notes', 'hidden', 'revision'})
            choice(segment, 'method', {'xml', 'pdf_text', 'native', 'visual', 'user_transcription'})
            segments[bid] = segment
        index[sid] = (source, segments)
    return index


def resolve_evidence(refs, source_index):
    resolved = []
    for ref in refs:
        sid, bid, quote = text(ref, 'source_id'), text(ref, 'segment_id'), text(ref, 'quote')
        if sid not in source_index or bid not in source_index[sid][1]:
            raise BuildError(f'根拠の参照先が存在しません: {sid}/{bid}')
        source, segments = source_index[sid]
        segment = segments[bid]
        if normal(quote) not in normal(segment['text']):
            raise BuildError(f'引用が転記セグメントと一致しません: {sid}/{bid}')
        resolved.append({**ref, 'file': source['file'], 'title': source['title'], 'revision': source.get('revision'),
                         'url': source.get('url'), 'locator': segment['locator'], 'read_status': segment['read_status'],
                         'channel': segment['channel'], 'method': segment['method'], 'source_role': source['role'], 'source_state': source['state'],
                         'metadata_basis': source.get('metadata_basis'), 'effective_from': source.get('effective_from'),
                         'effective_to': source.get('effective_to')})
    return resolved


def compile_manifest(manifest):
    if not isinstance(manifest, dict) or manifest.get('schema_version') != '1.0':
        raise BuildError('schema_version=1.0 のJSONが必要です。')
    package = manifest.get('package')
    if not isinstance(package, dict):
        raise BuildError('packageがありません。')
    name = text(package, 'name')
    if not SLUG.fullmatch(name) or len(name) > 64:
        raise BuildError('package.nameは64文字以内の英小文字・数字・ハイフンです。')
    text(package, 'title')
    version = text(package, 'version')
    if not re.fullmatch(r'\d+\.\d+\.\d+', version):
        raise BuildError('package.versionは例0.1.0の形式にしてください。')
    asof = iso_date(package.get('generated_on'))
    source_index = validate_sources(manifest)
    candidates = objects(manifest, 'candidates')
    keys = [text(c, 'key') for c in candidates]
    if len(keys) != len(set(keys)):
        raise BuildError('ルールkeyが重複しています。')
    if any(not re.fullmatch(r'[a-z0-9]+(?:[._-][a-z0-9]+)*', key) or len(key)>160 or key!=c['key'] for key,c in zip(keys,candidates)):
        raise BuildError('keyは160文字以内の英小文字・数字と . _ - を使用してください。')
    relationships = {key: set() for key in keys}
    for candidate in candidates:
        for conflict in strings(candidate, 'conflicts_with'):
            if conflict not in relationships or conflict == candidate['key']:
                raise BuildError('conflicts_withが未知のID又は自己参照です。')
            relationships[candidate['key']].add(conflict)
            relationships[conflict].add(candidate['key'])
    rules = []
    for candidate in candidates:
        for field in ('key', 'title', 'requirement', 'check_procedure', 'fail_condition', 'unknown_handling'):
            text(candidate, field)
        classification = choice(candidate, 'classification', CLASSES)
        strings(candidate, 'exceptions')
        scope = candidate.get('scope')
        if not isinstance(scope, dict):
            raise BuildError('scopeがありません。')
        level = choice(scope, 'level', LEVELS)
        text(scope, 'condition')
        strings(scope, 'targets')
        if type(scope.get('confirmed')) is not bool:
            raise BuildError('scope.confirmedはtrue/falseです。')
        evidence = resolve_evidence(objects(candidate, 'evidence'), source_index)
        scope_evidence = resolve_evidence(objects(scope, 'evidence'), source_index)
        blockers = []
        if type(candidate.get('context_verified')) is not bool:
            raise BuildError('context_verifiedはtrue/falseです。')
        if not candidate['context_verified']:
            blockers.append('見出し・表頭・前後の文脈・例外の確認が未完了')
        if not evidence:
            blockers.append('要求文の根拠がない')
        if not scope_evidence or not scope['confirmed'] or level == 'unknown':
            blockers.append('適用範囲の根拠が未確定')
        if level != 'company' and not scope['targets']:
            blockers.append('適用対象の識別がない')
        for ref in evidence + scope_evidence:
            source = source_index[ref['source_id']][0]
            if ref['read_status'] != 'clear':
                blockers.append('根拠の読取りが不確か')
            if source['coverage'] == 'unreadable':
                blockers.append('根拠資料が読取り不能と記録されている')
            if ref['channel'] in {'notes', 'hidden', 'revision'}:
                blockers.append('ノート・非表示・変更履歴のみを正式要求へ昇格しない')
            if source['state'] != 'current':
                blockers.append('資料の有効状態が未確定又は無効')
            if not source.get('revision') or not source.get('metadata_basis'):
                blockers.append('版・資料位置付けの根拠が未確定')
            if source['role'] not in {'standard', 'drawing'}:
                blockers.append('参考・教育・不明な資料を正式要求へ昇格しない')
            if source['role'] == 'drawing' and level != 'drawing':
                blockers.append('個別図面の要求を全社・製品一般へ拡張しない')
            if source.get('effective_from') and iso_date(source['effective_from']) > asof:
                blockers.append('資料の施行前')
            if source.get('effective_to') and iso_date(source['effective_to']) < asof:
                blockers.append('資料の有効期間外')
        conflicts = sorted(relationships[candidate['key']])
        if conflicts:
            blockers.append('競合ルールの適用関係が未解決')
        blockers = list(dict.fromkeys(blockers))
        if classification in {'example', 'inferred'}:
            status = 'reference_only'
        elif blockers:
            status = 'pending'
        elif classification == 'recommendation':
            status = 'advisory'
        else:
            status = 'usable'
        rules.append({**candidate, 'rule_id': rule_id(name, candidate['key']), 'status': status, 'blockers': blockers,
                      'conflicts_with': conflicts, 'evidence': evidence, 'scope': {**scope, 'evidence': scope_evidence}})
    return {'schema_version': '1.0', 'builder_version': VERSION, 'package': package, 'sources': manifest['sources'],
            'rules': rules, 'validation_scope': '内部参照・引用転記一致・分類ガードを検証。原本の読取り、意味、例外抽出の正確さは検証していない。'}


def comparison(current, previous):
    if previous is None:
        return {'added': [r['rule_id'] for r in current['rules']], 'changed': [], 'unchanged': [], 'not_present': []}
    if not isinstance(previous, dict) or previous.get('schema_version') != '1.0' or not isinstance(previous.get('rules'), list):
        raise BuildError('前回資料は生成済みrule-catalog.jsonを指定してください。')
    if not isinstance(previous.get('package'), dict):
        raise BuildError('前回資料のpackageが不正です。')
    if previous['package'].get('name') != current['package']['name']:
        raise BuildError('前回と今回のpackage.nameが異なります。')
    seen = set()
    for old_rule in previous['rules']:
        if not isinstance(old_rule, dict):
            raise BuildError('前回資料のrulesが不正です。')
        key, rid = text(old_rule, 'key'), text(old_rule, 'rule_id')
        if rid != rule_id(current['package']['name'], key) or rid in seen:
            raise BuildError('前回資料のルールIDが不正又は重複しています。')
        seen.add(rid)
    before = {r['rule_id']: r for r in previous['rules']}
    after = {r['rule_id']: r for r in current['rules']}
    fields = ('title', 'requirement', 'check_procedure', 'fail_condition', 'unknown_handling', 'exceptions', 'classification', 'status', 'scope', 'evidence', 'conflicts_with', 'blockers')
    changed, same = [], []
    for key in sorted(before.keys() & after.keys()):
        (same if all(before[key].get(f) == after[key].get(f) for f in fields) else changed).append(key)
    return {'added': sorted(after.keys() - before.keys()), 'changed': changed, 'unchanged': same,
            'not_present': sorted(before.keys() - after.keys()),
            'note': 'not_presentは今回入力にないという意味で、廃止の判定ではない。旧版を削除・失効させていない。'}


def evidence_lines(refs):
    lines = []
    for ref in refs:
        lines.append(f"- {ref['title']} / {ref.get('revision') or '版不明'} / {ref['locator']} / {ref['source_id']}:{ref['segment_id']}")
        lines.append(f"  根拠抜粋: {ref['quote']}")
        lines.append(f"  有効期間: {ref.get('effective_from') or '開始日未記録'} 〜 {ref.get('effective_to') or '終了日未記録'}（未記録は無期限という意味ではない）")
        if ref.get('url'):
            lines.append('  原本参照: ' + ref['url'])
    return lines


def rule_lines(rule):
    return [f"{rule['rule_id']} | {rule['title']}", f"分類: {rule['classification']} / 適用状態: {rule['status']}",
            f"適用範囲: {rule['scope']['level']} / 対象: {', '.join(rule['scope']['targets']) or '全社範囲の根拠を参照'}",
            '適用条件: ' + rule['scope']['condition'], '要求内容: ' + rule['requirement'],
            '確認手順: ' + rule['check_procedure'], '指摘条件: ' + rule['fail_condition'],
            '例外: ' + (' / '.join(rule['exceptions']) or '抽出資料では確認されていない。例外がないという断定ではない。'),
            '不明時: ' + rule['unknown_handling'], '要求の根拠:', *evidence_lines(rule['evidence']),
            '適用範囲の根拠:', *evidence_lines(rule['scope']['evidence'])]


