"""Read-only rule compilation with explicit release approval gates.

Digest checks detect mismatches; they do NOT authenticate the approver. Protect
release files through organizational access controls and an approval workflow.
"""
import copy
import json
from pathlib import Path
from rule_engine import BuildError, compile_manifest, comparison, iso_date
from package_skill import digest

ROOT = Path(__file__).resolve().parents[1]
CANDIDATE_FIELDS = ('key','title','classification','requirement','check_procedure',
    'fail_condition','unknown_handling','exceptions','context_verified','evidence','scope','conflicts_with')


def raw_candidate(rule):
    return {key:copy.deepcopy(rule[key]) for key in CANDIDATE_FIELDS}


def approval_valid(record, asof):
    if not isinstance(record,dict):
        return False
    if not all(isinstance(record.get(k),str) and record[k].strip() and record[k].strip() not in {'未確認','未取得','不明','TODO'}
               for k in ('approved_by','approved_on','approval_record')):
        return False
    try:
        iso_date(record['approved_on'])
        if record.get('valid_until'):
            iso_date(record['valid_until'])
    except (ValueError,TypeError):
        return False
    return record['approved_on']<=asof and (not record.get('valid_until') or asof<=record['valid_until'])


def load_json(root, name):
    return json.loads((Path(root)/'references'/name).read_text(encoding='utf-8'))


def recompile(catalog, asof, root=ROOT):
    """Recheck source dates/context and then require content-bound approval."""
    if not isinstance(catalog,dict) or catalog.get('schema_version')!='1.0':
        raise BuildError('内包台帳の形式が不正です。')
    compiled=compile_manifest({'schema_version':'1.0',
        'package':{**catalog['package'],'generated_on':asof},'sources':catalog['sources'],
        'candidates':[raw_candidate(r) for r in catalog['rules']]})
    comparison(compiled,catalog)
    old={r['key']:r for r in catalog['rules']}
    approvals=load_json(root,'rule-approvals.json')
    records={r['rule_id']:r for r in approvals.get('approved_rules',[])}
    if len(records)!=len(approvals.get('approved_rules',[])):
        raise BuildError('承認ルールIDが重複しています。')
    for rule in compiled['rules']:
        for field in ('lifecycle','lifecycle_reason','retirement_evidence','legacy_rule_ids'):
            if field in old[rule['key']]:
                rule[field]=copy.deepcopy(old[rule['key']][field])
        record=records.get(rule['rule_id'])
        approved=(approvals.get('catalog_digest')==digest(catalog) and approval_valid(record,asof)
                  and record.get('rule_digest')==digest(raw_candidate(rule)))
        rule['release_approved']=bool(approved)
        if rule.get('lifecycle') in {'removal_candidate','retired'}:
            rule['status']='pending'
            rule['blockers']=list(dict.fromkeys(rule['blockers']+[rule.get('lifecycle_reason','廃止候補又は廃止')]))
        if rule['status'] in {'usable','advisory'} and not approved:
            rule['status']='pending'
            rule['blockers']=list(dict.fromkeys(rule['blockers']+['内容・版に対応した有効な採用承認記録がない']))
    return compiled


def scope_match(rule, drawing):
    """Exact matches only. Free-text conditions still require contextual review."""
    scope=rule['scope']
    key={'company':'company','product':'product','process':'process','project':'project','drawing':'drawing_scope'}.get(scope['level'])
    if not key or not scope.get('confirmed'):
        return 'unknown'
    actual=drawing.get(key)
    if scope['level']=='drawing' and not actual:
        actual=f"{drawing['number']} Rev.{drawing['revision']}"
    if not actual:
        return 'unknown'
    targets=scope.get('targets',[])
    if scope['level']=='company' and not targets:
        return 'applicable'
    return 'applicable' if actual in targets else 'not_applicable'


def get_normative_entry(evidence_id, root, asof):
    registry=load_json(root,'normative-evidence.json')
    approvals=load_json(root,'rule-approvals.json')
    entries=[r for r in registry.get('entries',[]) if r.get('evidence_id')==evidence_id]
    records=[r for r in approvals.get('normative_approvals',[]) if r.get('evidence_id')==evidence_id]
    if len(entries)!=1 or len(records)!=1:
        raise ValueError('規格条項の登録又は採用承認がありません: '+evidence_id)
    item,record=entries[0],records[0]
    fields=('standard','edition','clause','source_file','locator','source_sha256','requirement','applicability')
    if any(not isinstance(item.get(k),str) or item[k].strip() in {'','未取得','未確認','不明','TODO'} for k in fields):
        raise ValueError('規格本文の根拠情報が不足しています。書誌情報だけでは判定できません。')
    import re
    if not re.fullmatch(r'[0-9a-f]{64}',item['source_sha256']):
        raise ValueError('規格原典のSHA-256が不正です。')
    if item.get('content_kind')!='verified_requirement' or item.get('rights_confirmed') is not True:
        raise ValueError('規格本文照合・利用権限の確認が未完了です。')
    if (approvals.get('normative_digest')!=digest(registry) or not approval_valid(record,asof)
        or record.get('evidence_digest')!=digest(item)):
        raise ValueError('規格条項と承認記録の版・内容・有効期限が一致しません。')
    return item
