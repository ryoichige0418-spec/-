"""Create one .xlsx review report and recover prior findings and editable notes.

The standard-library OOXML writer runs in the Copilot sandbox without installs.
Judgments originate in source-linked review input; this is not an OCR engine.
"""
import argparse
import copy
import hashlib
import json
import math
import posixpath
import re
import unicodedata
import zipfile
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape
import check_dimensions
from runtime_catalog import ROOT, recompile
from package_skill import digest
from rule_engine import iso_date, text, objects, choice

STATUSES = {'確認範囲で適合', '指摘あり', '要確認', '判定不能', '規格照合待ち', '対象外', '未実施'}
ISSUES = {'指摘あり', '要確認', '判定不能', '規格照合待ち'}
BASIS = {'図面内整合', '算術', '一般確認観点', '規格本文照合', '社内規則照合'}
LABELS = {'all': '全体検図', 'focus': '重点検図', 'recheck': '再検図', 'general': '一般ルール',
    'usable': '明示要求', 'advisory': '推奨', 'reference_only': '参考', 'pending': '保留',
    'clear': '確認済み', 'partial': '一部未確認', 'unreadable': '読取り不可', 'unknown': '未確認',
    'dimensions': '寸法', 'fits': '穴と軸', 'chains': '寸法連鎖', 'calculated': '計算済み',
    'inconsistent': '数値不整合', 'needs_source': '参照資料待ち', 'needs_confirmation': '要確認',
    'not_applicable': '演算対象外', 'invalid_input': '入力不備'}
N = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
     'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}


def finding_id(rule_id, target):
    return 'F-' + hashlib.sha256((rule_id + '\0' + target).encode()).hexdigest()[:12].upper()


def evidence(obj):
    if not isinstance(obj, dict):
        raise ValueError('sourceにはpage/location/rawが必要です。')
    if obj.get('page') is not None and (type(obj['page']) is not int or obj['page'] < 1):
        raise ValueError('source.pageは1以上の整数又はnullです。')
    text(obj, 'location')
    text(obj, 'raw')
    return obj


def normalize(data, root=ROOT, previous=None):
    data = copy.deepcopy(data)
    if not isinstance(data, dict) or data.get('schema_version') != '2.0':
        raise ValueError('レポート入力はschema_version=2.0です。')
    asof = text(data, 'reviewed_on')
    iso_date(asof)
    text(data, 'review_id')
    choice(data, 'mode', {'all', 'focus', 'recheck'})
    drawing = data.get('drawing')
    if not isinstance(drawing, dict):
        raise ValueError('drawingが必要です。')
    for field in ('file', 'number', 'revision'):
        text(drawing, field)
    catalog = json.loads((Path(root) / 'references/rule-catalog.json').read_text(encoding='utf-8'))
    runtime = recompile(catalog, asof, root=root)
    general = json.loads((Path(root) / 'references/rules.json').read_text(encoding='utf-8'))
    rules = {r['id']: {'title': r['title'], 'status': 'general'} for r in general['rules'] if r['enabled']}
    rules.update({r['rule_id']: r for r in runtime['rules']})
    rule_set = {'version': catalog['package']['version'], 'digest': digest(catalog),
                'general_version': general['version'], 'general_digest': digest(general),
                'approval_digest': digest(json.loads((Path(root)/'references/rule-approvals.json').read_text(encoding='utf-8'))),
                'normative_digest': digest(json.loads((Path(root)/'references/normative-evidence.json').read_text(encoding='utf-8')))}
    if 'rule_set' in data and data['rule_set'] != rule_set:
        raise ValueError('入力のルール版が実行スキルと一致しません。読み直してください。')
    checks = objects(data, 'checks')
    seen = set()
    for row in checks:
        rid, target = text(row, 'rule_id'), text(row, 'target')
        if rid not in rules or (rid, target) in seen:
            raise ValueError('未知のルールID又はルール×対象の重複です。')
        seen.add((rid, target))
        status = choice(row, 'status', STATUSES)
        text(row, 'reason')
        choice(row, 'basis_type', BASIS)
        choice(row, 'read_status', {'確認済み', '不確か', '読取り不可'})
        evidence(row.get('source'))
        rule = rules[rid]
        row['rule_title'], row['rule_state'] = rule['title'], rule['status']
        if rule['status'] in {'pending', 'reference_only'} and status in {'確認範囲で適合', '指摘あり'}:
            raise ValueError('保留・参考ルールで適合又は違反を判定できません。')
        if rule['status'] == 'advisory' and status == '指摘あり':
            raise ValueError('推奨ルールは違反判定に使えません。要確認と改善提案で示してください。')
        if row['read_status'] != '確認済み' and status in {'確認範囲で適合', '指摘あり'}:
            raise ValueError('原図の読取り未確定で適合又は違反を判定できません。')
        if row['basis_type'] in {'規格本文照合', '社内規則照合'}:
            text(row, 'reference')
        if row['basis_type'] == '規格本文照合':
            for field in ('standard', 'edition', 'clause', 'source_file', 'locator', 'applicability'):
                text(row.get('standard_evidence', {}), field)
        if status in ISSUES:
            text(row, 'action')
            choice(row, 'importance', {'高', '中', '低', '未評価'})
    supplied = {r['rule_id'] for r in checks}
    for rid, rule in rules.items():
        if rid in supplied:
            continue
        retired = rule.get('lifecycle') == 'retired'
        inactive = rule['status'] in {'pending', 'reference_only'}
        status = '対象外' if retired or rule['status'] == 'reference_only' else ('要確認' if inactive else '未実施')
        checks.append({'rule_id': rid, 'rule_title': rule['title'], 'rule_state': rule['status'],
            'target': '適用範囲未確認', 'status': status,
            'reason': ('明示廃止済み。履歴として保持。' if retired else
                       '参考情報。必須ルールへ採用しない。' if rule['status'] == 'reference_only' else
                       'ルール保留: ' + ' / '.join(rule['blockers']) if inactive else '対象ごとの実施記録がありません。'),
            'source': {'page': None, 'location': '未確認', 'raw': '未取得'},
            'basis_type': '社内規則照合' if rid.startswith('CORP-') else '一般確認観点',
            'read_status': '読取り不可', 'reference': '', 'importance': '未評価',
            'action': '保留根拠と適用範囲を確認する。' if inactive else '対象を特定して確認する。',
            'automatically_added': True})
    coverage = objects(data, 'coverage')
    if not coverage:
        coverage.append({'page': None, 'region': '全体', 'status': 'unknown', 'note': 'ページと確認範囲の記録がありません。'})
    for row in coverage:
        if row.get('page') is not None and (type(row['page']) is not int or row['page'] < 1):
            raise ValueError('coverage.pageは1以上の整数又はnullです。')
        choice(row, 'status', {'clear', 'partial', 'unreadable', 'unknown'})
        text(row, 'region')
        text(row, 'note')
    numeric = None
    if data.get('numeric_input') is not None:
        if data['numeric_input'].get('drawing') != drawing:
            raise ValueError('数値入力の図面識別情報が検図対象と異なります。')
        numeric = check_dimensions.review(data['numeric_input'])
        for category in ('dimensions', 'fits', 'chains'):
            for row in numeric[category]:
                if row['status'] in {'calculated', 'not_applicable'}:
                    continue
                ev = row.get('evidence') or {}
                checks.append({'rule_id': row['rule_id'], 'rule_title': rules[row['rule_id']]['title'],
                    'rule_state': 'general', 'target': '数値入力 ' + row['id'],
                    'status': '未実施' if row['status'] == 'invalid_input' else '要確認',
                    'reason': '数値計算: ' + row.get('message', row['status']),
                    'source': {'page': ev.get('page'), 'location': ev.get('region', '未確認'), 'raw': ev.get('raw', '未取得')},
                    'basis_type': '算術', 'read_status': '不確か', 'importance': '未評価',
                    'action': '原図、入力と計算台帳を照合する。', 'automatically_added': True})
    findings = []
    for row in checks:
        if row['status'] in ISSUES:
            findings.append({**row, 'finding_id': finding_id(row['rule_id'], row['target']), 'memo': ''})
    prior_rows = []
    if previous is not None:
        if data['mode'] != 'recheck' or previous.get('schema_version') != '2.0':
            raise ValueError('前回レポートは再検図モードで指定してください。')
        if previous['drawing']['number'] != drawing['number']:
            raise ValueError('前回と今回の図番が異なります。対象を再確認してください。')
        if drawing['number'] == '不明' and not data.get('drawing_match_basis'):
            raise ValueError('図番不明の再検図には原図対応を確認した根拠が必要です。')
        old_findings = {r['finding_id']: r for r in previous['findings']}
        resolutions = {}
        for item in objects({'rows': data.get('resolutions', [])}, 'rows'):
            fid = text(item, 'finding_id')
            if fid not in old_findings or fid in resolutions:
                raise ValueError('前回指摘IDが未知又は重複しています。')
            result = choice(item, 'result', {'解消', '継続', '再確認必要'})
            text(item, 'reason')
            evidence(item.get('source'))
            old = old_findings[fid]
            matching = [r for r in checks if r['rule_id'] == old['rule_id'] and r['target'] == old['target']]
            if result == '解消' and not any(r['status'] == '確認範囲で適合' and r['read_status'] == '確認済み' for r in matching):
                raise ValueError('解消には同じ対象の原図確認と適合記録が必要です。消失だけで解消にしないでください。')
            if result == '継続' and not any(r['status'] in ISSUES for r in matching):
                raise ValueError('継続には同じ対象の今回の確認記録が必要です。不明なら再確認必要としてください。')
            resolutions[fid] = item
        for fid, old in old_findings.items():
            result = resolutions.get(fid, {'finding_id': fid, 'result': '再確認必要',
                'reason': '今回の確認結果がありません。解消扱いにしていません。',
                'source': {'page': None, 'location': '未確認', 'raw': '未取得'}})
            prior_rows.append({**result, 'rule_id': old['rule_id'], 'target': old['target'],
                               'previous_reason': old['reason'], 'memo': old.get('memo', '')})
            if result['result'] != '解消' and not any(r['finding_id'] == fid for r in findings):
                carried = copy.deepcopy(old)
                carried.update(status='要確認', read_status='不確か',
                    action='前回指摘の未確認分です。新版の同じ対象を確認する。', carry_forward=True)
                carried['source']['location'] = '前回図面: ' + carried['source']['location'].removeprefix('前回図面: ')
                findings.append(carried)
        for row in findings:
            if row['finding_id'] in old_findings:
                row['memo'] = old_findings[row['finding_id']].get('memo', '')
    elif data['mode'] == 'recheck':
        raise ValueError('再検図には前回レポートの引継ぎデータが必要です。')
    findings.sort(key=lambda r: {'高': 0, '中': 1, '未評価': 2, '低': 3}[r['importance']])
    statuses = dict(Counter(r['status'] for r in checks))
    summary = {'finding_count': len(findings), 'rule_count': len(rules), 'check_row_count': len(checks),
        'status_counts': statuses, 'unread_region_count': sum(r['status'] != 'clear' for r in coverage),
        'corporate_rules_registered': len(catalog['rules']),
        'numeric_status_counts': numeric['counts'] if numeric else {},
        'previous_rule_set_changed': bool(previous and previous['rule_set'] != rule_set)}
    return {'schema_version': '2.0', 'review_id': data['review_id'], 'reviewed_on': asof,
        'drawing': drawing, 'mode': data['mode'], 'rule_set': rule_set, 'summary': summary,
        'checks': checks, 'findings': findings, 'coverage': coverage, 'numeric': numeric,
        'recheck': prior_rows, 'scope': '原図の読取り・意味判断は入力記録に依存。出図承認ではない。'}


def fmt_target(row):
    label=row.get('target_label','')
    return row['target'] + (' — '+label if label and label!=row['target'] else '')


def fmt_source(source):
    return f"p.{source.get('page') or '不明'} {source['location']}\n{source['raw']}"


def numeric_details(row):
    labels = {'minimum': '下限', 'maximum': '上限', 'width': '公差幅',
              'minimum_clearance': '最小すきま', 'maximum_clearance': '最大すきま',
              'derived_minimum': '導出下限', 'derived_maximum': '導出上限',
              'target_minimum': '目標下限', 'target_maximum': '目標上限'}
    lines = [f'{label}: {row[key]} {row.get("unit", "")}'.rstrip() for key, label in labels.items() if key in row]
    classes = {'clearance_side': 'すきま側', 'interference_side': 'しまり側',
               'transition': '正負のすきま範囲を含む', 'line_to_line': '上下限ともすきま0',
               'contained': '目標範囲内', 'overlap_only': '目標範囲と一部重複のみ', 'disjoint': '目標範囲との重複なし'}
    if row.get('classification'):
        lines.append('区間の分類: ' + classes.get(row['classification'], row['classification']))
    if row.get('dimension_ids'):
        lines.append('穴 / 軸の寸法ID: ' + ' / '.join(row['dimension_ids']))
    if row.get('terms'):
        lines.append('導出式: ' + ' '.join(('+' if t['sign'] == 1 else '−') + t['dimension_id'] for t in row['terms']))
        lines.append('目標寸法ID: ' + row['target_id'])
    if row.get('formula'):
        lines.append(row['formula'])
    return '\n'.join(lines) or '計算できていません。注意欄を確認してください。'


def col(index):
    result = ''
    while index:
        index, rem = divmod(index - 1, 26)
        result = chr(65 + rem) + result
    return result


def safe_xml(value):
    value = str(value)
    if re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]', value) or len(value) > 32767:
        raise ValueError('Excelセルに保存できない文字又は長すぎる値があります。')
    # Excel's escaped-character syntax must not reinterpret literal source text.
    value = re.sub(r'_x(?=[0-9A-Fa-f]{4}_)', '_x005F_x', value).replace('\r', '_x000D_')
    return escape(value)


def cell_text(node):
    """Read plain/rich text without appending Japanese phonetic annotations."""
    if node is None:
        return ''
    parts = []
    for child in node:
        if child.tag == '{' + N['s'] + '}t':
            parts.append(child.text or '')
        elif child.tag == '{' + N['s'] + '}r':
            parts.extend(t.text or '' for t in child.findall('s:t', N))
    return re.sub(r'_x([0-9A-Fa-f]{4})_', lambda m: chr(int(m.group(1), 16)), ''.join(parts))


def write_xlsx(report, output):
    summary = report['summary']
    rows = [['項目', '結果'], ['図面', report['drawing']['file']], ['図番 / 改訂', report['drawing']['number'] + ' / ' + report['drawing']['revision']],
        ['検図日 / モード', report['reviewed_on'] + ' / ' + LABELS[report['mode']]], ['使用ルール版', report['rule_set']['version']],
        ['指摘・確認事項の行数', summary['finding_count']], ['未実施の行数', summary['status_counts'].get('未実施', 0)],
        ['未確認領域の件数', summary['unread_region_count']], ['ルール数 / 記録行数', f"{summary['rule_count']} / {summary['check_row_count']}"],
        ['社内ルール', f"台帳登録 {summary['corporate_rules_registered']}件" if summary['corporate_rules_registered'] else '未登録。社内規則の照合は未実施。'],
        ['前回からのルール変更', 'あり。判定条件の変更も確認。' if summary['previous_rule_set_changed'] else 'なし / 前回なし'],
        ['計算', '、'.join(f'{LABELS.get(k, k)} {v}件' for k, v in summary['numeric_status_counts'].items()) if report['numeric'] else '数値スクリプト未実行'],
        ['読み方', '指摘・確認事項と未確認範囲を確認してください。指摘0件でも未実施は残ります。'],
        ['対応メモ', '指摘シートの対応メモ欄を編集できます。再検図時に引き継ぎます。判定・根拠欄の手編集は引継ぎ対象外です。'],
        ['記録の範囲', report['scope']]]
    rows += [['入力契約 / ガード版', report.get('input_schema','2.0') + ' / ' + report.get('guard_version','旧版')],
             ['対象内の必要確認 / 未実施', f"{summary.get('expected_check_count','未集計')} / {summary.get('unexecuted_expected_count','未集計')}"],
             ['採用済み規格条項', summary.get('adopted_normative_entries',0)],
             ['原図SHA-256', report['drawing'].get('sha256','旧版は未記録')]]
    sheets = [('概要', rows, [27, 90], False)]
    fields = [['指摘ID', '重要度', '対象', '指摘・確認事項', '確認案', '対応メモ', 'ルールID', '判定', '原図・原文', '根拠種別', '参照箇所']]
    for row in report['findings']:
        fields.append([row['finding_id'], row['importance'], fmt_target(row), row['reason'], row['action'], row.get('memo', ''), row['rule_id'], row['status'], fmt_source(row['source']), row['basis_type'], row.get('reference', '')])
    sheets.append(('指摘', fields, [22, 10, 26, 45, 42, 38, 24, 22, 48, 20, 40], False))
    rows = [['ルールID', 'ルール名', '対象', '判定', '確認内容・理由', '原図・原文', '読取り', 'ルール状態', '参照箇所']]
    for row in report['checks']:
        rows.append([row['rule_id'], row['rule_title'], fmt_target(row), row['status'], row['reason'], fmt_source(row['source']), row['read_status'], LABELS[row['rule_state']], row.get('reference', '')])
    sheets.append(('実施一覧', rows, [24, 36, 30, 24, 55, 50, 16, 16, 42], False))
    rows = [['ページ', '領域', '読取り状態', '確認範囲・未確認事項']]
    rows += [[r.get('page') or '不明', r['region'], LABELS[r['status']], r['note']] for r in report['coverage']]
    sheets.append(('確認範囲', rows, [12, 36, 18, 80], False))
    rows = [['区分', 'ID', '状態', '原図の位置・原文', '計算結果・式', '計算上の注意']]
    if report['numeric']:
        for category in ('dimensions', 'fits', 'chains'):
            for r in report['numeric'][category]:
                ev = r.get('evidence', {})
                source = fmt_source({'page': ev.get('page'), 'location': ev.get('region', '未確認'), 'raw': ev.get('raw', '未取得')}) if isinstance(ev, dict) else '根拠の形式不正。元の転記を確認してください。'
                message = r.get('message', '')
                if category == 'chains' and r['status'] == 'calculated':
                    message = '独立区間の最悪値計算。組立保証や不良率の判定ではありません。'
                rows.append([LABELS[category], r['id'], LABELS.get(r['status'], r['status']), source,
                    numeric_details(r), message])
    else:
        rows.append(['未実行', '', '', '', '', '明示数値の原図転記がないため計算していません。'])
    sheets.append(('計算台帳', rows, [16, 20, 24, 45, 78, 50], False))
    rows = [['前回指摘ID', '今回の状態', '対象', '前回の指摘', '今回の理由', '確認した原図', '対応メモ']]
    rows += [[r['finding_id'], r['result'], r['target'], r['previous_reason'], r['reason'], fmt_source(r['source']), r.get('memo', '')] for r in report['recheck']]
    sheets.append(('再検図', rows, [24, 20, 28, 45, 45, 48, 38], False))
    payload = json.dumps(report, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    rows = [['形式', 'drawing-review-report-v2'], ['SHA256', hashlib.sha256(payload.encode()).hexdigest()]]
    rows += [[i // 30000, payload[i:i + 30000]] for i in range(0, len(payload), 30000)]
    sheets.append(('引継ぎデータ', rows, [16, 90], True))
    contents = {}
    for i, (name, matrix, widths, hidden) in enumerate(sheets, 1):
        body = []
        for ri, row in enumerate(matrix, 1):
            cells, lines = [], 1
            for ci, value in enumerate(row, 1):
                if type(value) in {int, float}:
                    cells.append(f'<c r="{col(ci)}{ri}" s="{1 if ri == 1 else 2}"><v>{value}</v></c>')
                else:
                    cells.append(f'<c r="{col(ci)}{ri}" s="{1 if ri == 1 else 2}" t="inlineStr"><is><t xml:space="preserve">{safe_xml(value)}</t></is></c>')
                if not hidden:
                    lines = max(lines, sum(max(1, math.ceil(sum(2 if unicodedata.east_asian_width(ch) in 'WF' else 1 for ch in part) / max(8, widths[ci - 1] - 2))) for part in str(value).split('\n')))
            height = 30 if ri == 1 else max(30, lines * 16 + 10)
            if not hidden and height > 409:
                raise ValueError(f'{name}の{ri}行が長すぎます。原文抜粋や説明を分割してください。')
            body.append(f'<row r="{ri}" ht="{min(height, 409)}" customHeight="1">' + ''.join(cells) + '</row>')
        cols = ''.join(f'<col min="{j}" max="{j}" width="{width}" customWidth="1"/>' for j, width in enumerate(widths, 1))
        filter_xml = f'<autoFilter ref="A1:{col(len(widths))}{len(matrix)}"/>' if not hidden and i != 1 else ''
        contents[f'xl/worksheets/sheet{i}.xml'] = f'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="{N["s"]}"><sheetViews><sheetView workbookViewId="0" showGridLines="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>{cols}</cols><sheetData>{"".join(body)}</sheetData>{filter_xml}<pageSetup orientation="landscape" paperSize="9"/></worksheet>'
    contents['xl/workbook.xml'] = f'<workbook xmlns="{N["s"]}" xmlns:r="{N["r"]}"><sheets>' + ''.join(f'<sheet name="{name}" sheetId="{i}" r:id="rId{i}"' + (' state="hidden"' if hidden else '') + '/>' for i, (name, _, _, hidden) in enumerate(sheets, 1)) + '</sheets></workbook>'
    rel_ns = 'http://schemas.openxmlformats.org/package/2006/relationships'
    contents['xl/_rels/workbook.xml.rels'] = f'<Relationships xmlns="{rel_ns}">' + ''.join(f'<Relationship Id="rId{i}" Type="{N["r"]}/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1, len(sheets) + 1)) + f'<Relationship Id="styles" Type="{N["r"]}/styles" Target="styles.xml"/></Relationships>'
    contents['_rels/.rels'] = f'<Relationships xmlns="{rel_ns}"><Relationship Id="root" Type="{N["r"]}/officeDocument" Target="xl/workbook.xml"/></Relationships>'
    contents['xl/styles.xml'] = f'<styleSheet xmlns="{N["s"]}"><fonts count="2"><font><sz val="11"/><name val="Yu Gothic"/><color rgb="FF243747"/></font><font><b/><sz val="11"/><name val="Yu Gothic"/><color rgb="FFFFFFFF"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF244A63"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'
    contents['[Content_Types].xml'] = '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + ''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1, len(sheets) + 1)) + '</Types>'
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as handle, zipfile.ZipFile(handle, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, value in contents.items():
            archive.writestr(name, value.encode('utf-8'))


def read_xlsx(path):
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        if len(infos) != len({i.filename for i in infos}) or sum(i.file_size for i in infos) > 100_000_000 or any(i.file_size > 32_000_000 for i in infos):
            raise ValueError('重複エントリ又はサイズ上限超過のExcelファイルです。')
        def xml(name):
            return ET.fromstring(archive.read(name))
        strings = []
        if 'xl/sharedStrings.xml' in archive.namelist():
            strings = [cell_text(x) for x in xml('xl/sharedStrings.xml').findall('s:si', N)]
        rels = {r.get('Id'): r for r in xml('xl/_rels/workbook.xml.rels')}
        sheet_paths = {}
        for sheet in xml('xl/workbook.xml').findall('s:sheets/s:sheet', N):
            rel = rels[sheet.get('{' + N['r'] + '}id')]
            if rel.get('TargetMode') == 'External':
                raise ValueError('外部シート参照には対応していません。')
            target = rel.get('Target')
            sheet_paths[sheet.get('name')] = target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/' + target)
        def values(name):
            result = []
            for row in xml(sheet_paths[name]).findall('s:sheetData/s:row', N):
                cells = {}
                for cell in row.findall('s:c', N):
                    coordinate = re.match(r'[A-Z]+', cell.get('r', '')).group()
                    if cell.find('s:f', N) is not None:
                        raise ValueError('引継ぎデータ又は対応メモのシートに数式があります。値として保存してください。')
                    value = cell.findtext('s:v', '', N)
                    if cell.get('t') == 's':
                        value = strings[int(value)]
                    elif cell.get('t') == 'inlineStr':
                        value = cell_text(cell.find('s:is', N))
                    cells[coordinate] = value
                result.append(cells)
            return result
        hidden = values('引継ぎデータ')
        if hidden[0].get('B') != 'drawing-review-report-v2':
            raise ValueError('このスキルで生成したv2レポートではありません。')
        chunks = hidden[2:]
        if [r.get('A') for r in chunks] != [str(i) for i in range(len(chunks))]:
            raise ValueError('引継ぎデータの分割番号が不正です。')
        payload = ''.join(r.get('B', '') for r in chunks)
        if hashlib.sha256(payload.encode()).hexdigest() != hidden[1].get('B'):
            raise ValueError('引継ぎデータが破損又は編集されています。')
        report = json.loads(payload)
        if report.get('schema_version') != '2.0':
            raise ValueError('未対応のレポート形式です。')
        fields = values('指摘')
        headers = fields[0]
        id_col = next(k for k, v in headers.items() if v == '指摘ID')
        memo_col = next(k for k, v in headers.items() if v == '対応メモ')
        notes = {}
        for row in fields[1:]:
            fid = row.get(id_col, '')
            if not fid:
                continue
            if fid in notes:
                raise ValueError('指摘IDが重複しています。')
            notes[fid] = row.get(memo_col, '')
        known = {r['finding_id'] for r in report['findings']}
        if set(notes) - known:
            raise ValueError('指摘IDが引継ぎデータと一致しません。')
        for row in report['findings']:
            row['memo'] = notes.get(row['finding_id'], row.get('memo', ''))
        return report


