#!/usr/bin/env python3
"""Explicit-value arithmetic for drawing review; no OCR or standards lookup.

Python standard library only. See references/numeric-input.txt for the contract.
All results are conditional on the supplied transcription and relationships.
"""
import argparse
import csv
import json
import re
from decimal import Decimal, localcontext
from pathlib import Path

VERSION = "0.1.0"
FACTORS = {"mm": "1", "cm": "10", "m": "1000", "um": "0.001", "µm": "0.001", "μm": "0.001", "in": "25.4", "deg": "1"}
FORMS = {"symmetric", "deviations", "limits", "code", "general", "nominal_only", "basic", "reference"}
KINDS = {"size", "coordinate", "angle"}
NUMBER = re.compile(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)\Z", re.ASCII)


class InputError(ValueError):
    pass


def number(value):
    # Strings preserve transcription exactly; floats/bools may hide conversion errors.
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise InputError("数値は十進数文字列または整数で指定してください。")
    text = str(value).strip()
    if len(text) > 32 or not NUMBER.fullmatch(text):
        raise InputError("数値の形式が不正です（単位、指数、NaN、桁区切りは不可）。")
    return Decimal(text)


def fmt(value):
    if value == 0:
        return "0"
    result = format(value, "f")
    return result.rstrip("0").rstrip(".") if "." in result else result


def required_text(row, key):
    value = row.get(key)
    if not isinstance(value, str) or not value.strip():
        raise InputError(f"{key} がありません。")
    return value.strip()


def evidence(row):
    ev = row.get("evidence")
    if not isinstance(ev, dict):
        raise InputError("原図の evidence がありません。")
    page = ev.get("page")
    if isinstance(page, bool) or not isinstance(page, int) or page < 1:
        raise InputError("evidence.page は1以上のページ番号にしてください。")
    required_text(ev, "region")
    required_text(ev, "raw")
    return ev


def base(row, rule):
    return {"id": row["id"], "rule_id": rule, "evidence": row.get("evidence"), "basis": "明示入力に対する算術。規格適合・製造可否の判定ではない。"}


def blocked(result, status, message):
    return {**result, "status": status, "message": message}


def dimension(row):
    out = base(row, "DM-002")
    try:
        evidence(row)
        read_status = row.get("read_status")
        if not isinstance(read_status, str) or read_status not in {"clear", "uncertain", "unreadable"}:
            raise InputError("read_status が不正です。")
        if read_status != "clear":
            return blocked(out, "unreadable", "読取りが確定していないため計算していません。")
        form = row.get("form")
        if not isinstance(form, str) or form not in FORMS:
            raise InputError("form が不正です。")
        if form in {"basic", "reference"}:
            return blocked(out, "not_applicable", "理論的に正確な寸法・参考寸法には独立した±公差を付加しません。")
        if form in {"code", "general", "nominal_only"}:
            return blocked(out, "needs_source", "適用規定・公差表・明示値を確認してください。本スクリプトに規格表はありません。")
        unit = row.get("unit")
        kind = row.get("kind")
        if not isinstance(unit, str) or unit not in FACTORS or not isinstance(kind, str) or kind not in KINDS:
            raise InputError("単位または寸法種別が不正です。")
        if (kind == "angle") != (unit == "deg"):
            raise InputError("角度と長さの単位が混在しています。")
        factor = Decimal(FACTORS[unit])
        if form == "limits":
            lo, hi = number(row.get("minimum")), number(row.get("maximum"))
            formula = "minimum, maximum = 図面に明示された下限, 上限"
        else:
            nominal = number(row.get("nominal"))
            if form == "symmetric":
                tolerance = number(row.get("tolerance"))
                if tolerance < 0:
                    return blocked(out, "inconsistent", "±公差の幅に負の値が入力されています。原図と転記を確認してください。")
                lower, upper = -tolerance, tolerance
            else:
                lower, upper = number(row.get("lower")), number(row.get("upper"))
            lo, hi = nominal + lower, nominal + upper
            formula = f"下限 = {fmt(nominal)} + ({fmt(lower)}); 上限 = {fmt(nominal)} + ({fmt(upper)}) [{unit}]"
        if lo > hi:
            return blocked(out, "inconsistent", "下限が上限を上回ります。上下・符号の転記と原図を確認してください。")
        if kind == "size" and lo < 0:
            return blocked(out, "inconsistent", "サイズの下限が負です。座標値との取り違えと原図を確認してください。")
        return {**out, "status": "calculated", "kind": kind, "unit": "deg" if kind == "angle" else "mm", "minimum": fmt(lo * factor), "maximum": fmt(hi * factor), "width": fmt((hi - lo) * factor), "formula": formula, "message": "入力値の数値整合のみ確認。図面全体の適合を意味しません。"}
    except InputError as exc:
        return blocked(out, "invalid_input", str(exc))


def resolved(rows, ref):
    if not isinstance(ref, str) or ref not in rows:
        raise InputError("参照した寸法IDがありません。")
    row = rows[ref]
    if row.get("status") != "calculated":
        raise InputError(f"寸法 {ref} は計算可能な確定値ではありません。")
    return row, Decimal(row["minimum"]), Decimal(row["maximum"])


def fit(row, rows):
    out = base(row, "DM-007")
    try:
        evidence(row)
        if row.get("mating_confirmed") is not True:
            return blocked(out, "needs_confirmation", "穴と軸の組合せが確認されていません。")
        if row.get("hole_id") == row.get("shaft_id"):
            raise InputError("穴と軸に同じ寸法IDは使えません。")
        hole, hlo, hhi = resolved(rows, row.get("hole_id"))
        shaft, slo, shi = resolved(rows, row.get("shaft_id"))
        if hole["kind"] != "size" or shaft["kind"] != "size":
            raise InputError("穴と軸はサイズで指定してください。")
        cmin, cmax = hlo - shi, hhi - slo
        if cmin == cmax == 0:
            classification = "line_to_line"
        elif cmin >= 0:
            classification = "clearance_side"
        elif cmax <= 0:
            classification = "interference_side"
        else:
            classification = "transition"
        return {**out, "status": "calculated", "unit": "mm", "minimum_clearance": fmt(cmin), "maximum_clearance": fmt(cmax), "classification": classification, "dimension_ids": [row["hole_id"], row["shaft_id"]], "formula": "最小すきま = 穴下限 − 軸上限; 最大すきま = 穴上限 − 軸下限", "message": "負のすきまはしめしろ。0境界を含む分類。公差クラスの規格照合・機能上の適否は未判定。"}
    except InputError as exc:
        return blocked(out, "invalid_input", str(exc))


def chain(row, rows):
    out = base(row, "DM-008")
    try:
        evidence(row)
        if row.get("relation_confirmed") is not True or row.get("independent_intervals") is not True:
            return blocked(out, "needs_confirmation", "一次元寸法連鎖と、各寸法を独立区間として扱う前提の確認が必要です。")
        terms = row.get("terms")
        if not isinstance(terms, list) or not terms or len(terms) > 100:
            raise InputError("terms は1～100項で指定してください。")
        target, tlo, thi = resolved(rows, row.get("target_id"))
        seen, lo, hi = set(), Decimal(0), Decimal(0)
        for term in terms:
            if not isinstance(term, dict):
                raise InputError("寸法連鎖の項が不正です。")
            dim_id = term.get("dimension_id")
            if not isinstance(dim_id, str) or dim_id in seen or dim_id == row.get("target_id"):
                raise InputError("同一寸法の重複使用・目標寸法の自己参照は扱いません。")
            seen.add(dim_id)
            sign = term.get("sign")
            if type(sign) is not int or sign not in {-1, 1}:
                raise InputError("sign は整数の1または-1にしてください。")
            dim, dlo, dhi = resolved(rows, dim_id)
            if dim["unit"] != target["unit"]:
                raise InputError("長さと角度を同じ連鎖で加減算できません。")
            lo += dlo if sign == 1 else -dhi
            hi += dhi if sign == 1 else -dlo
        if lo >= tlo and hi <= thi:
            classification = "contained"
        elif hi < tlo or lo > thi:
            classification = "disjoint"
        else:
            classification = "overlap_only"
        return {**out, "status": "calculated", "unit": target["unit"], "derived_minimum": fmt(lo), "derived_maximum": fmt(hi), "target_minimum": fmt(tlo), "target_maximum": fmt(thi), "classification": classification, "terms": terms, "target_id": row["target_id"], "message": "独立区間の最悪値計算。contained=目標範囲内、overlap_only=一部重複のみ、disjoint=重複なし。組立保証や不良率の判定ではありません。"}
    except InputError as exc:
        return blocked(out, "invalid_input", str(exc))


def validate_top(data):
    if not isinstance(data, dict) or data.get("schema_version") != "1.0":
        raise InputError("schema_version は 1.0 としてください。")
    drawing = data.get("drawing")
    if not isinstance(drawing, dict):
        raise InputError("drawing がありません。")
    for key in ("file", "number", "revision"):
        required_text(drawing, key)
    all_ids = set()
    for name in ("dimensions", "fits", "chains"):
        values = data.get(name, [])
        if not isinstance(values, list) or len(values) > 1000:
            raise InputError(f"{name} は1000件以下の配列にしてください。")
        for row in values:
            if not isinstance(row, dict):
                raise InputError(f"{name} の要素が不正です。")
            row_id = required_text(row, "id")
            if row_id != row["id"] or row_id in all_ids:
                raise InputError("IDの前後空白または重複を修正してください。")
            all_ids.add(row_id)


def review(data):
    validate_top(data)
    with localcontext() as ctx:
        ctx.prec = 80
        dims = [dimension(row) for row in data.get("dimensions", [])]
        index = {row["id"]: row for row in dims}
        fits = [fit(row, index) for row in data.get("fits", [])]
        chains = [chain(row, index) for row in data.get("chains", [])]
    counts = {}
    for row in dims + fits + chains:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"schema_version": "1.0", "engine_version": VERSION, "drawing": data["drawing"], "scope": "入力された寸法のみ。OCR、全寸法の抽出、JIS表照合、形状・機能の検証は未実施。", "dimensions": dims, "fits": fits, "chains": chains, "counts": counts}


def csv_cell(value):
    text = str(value)
    # A CSV opened in Excel must not execute a raw drawing annotation as a formula.
    return "'" + text if text.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")) else text


def write_csv(result, path):
    fields = ["category", "id", "rule_id", "status", "page", "region", "raw", "result", "message"]
    with Path(path).open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for category in ("dimensions", "fits", "chains"):
            for row in result[category]:
                ev = row.get("evidence")
                if not isinstance(ev, dict):
                    ev = {}
                details = {k: v for k, v in row.items() if k not in {"id", "rule_id", "status", "evidence", "message", "basis"}}
                record = {"category": category, "id": row["id"], "rule_id": row["rule_id"], "status": row["status"], "page": ev.get("page", ""), "region": ev.get("region", ""), "raw": ev.get("raw", ""), "result": json.dumps(details, ensure_ascii=False), "message": row["message"]}
                writer.writerow({key: csv_cell(value) for key, value in record.items()})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", help="numeric-input.txt に従ったJSON")
    parser.add_argument("--output", required=True, help="計算結果JSON")
    parser.add_argument("--csv", help="任意の計算結果CSV。総合指摘票とは別ファイルです。")
    args = parser.parse_args()
    paths = [Path(p).resolve() for p in (args.input, args.output, args.csv) if p]
    if len(paths) != len(set(paths)):
        parser.error("入力と出力、および出力同士は別のパスにしてください。")
    try:
        data = json.loads(Path(args.input).read_text(encoding="utf-8-sig"))
        result = review(data)
    except (InputError, json.JSONDecodeError, OSError) as exc:
        parser.exit(2, f"入力エラー: {exc}\n")
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if args.csv:
        Path(args.csv).parent.mkdir(parents=True, exist_ok=True)
        write_csv(result, args.csv)
    print(json.dumps({"output": str(output), "counts": result["counts"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
