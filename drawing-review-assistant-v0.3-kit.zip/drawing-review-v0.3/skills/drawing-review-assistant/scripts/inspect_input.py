"""Inspect file identity without OCR or dependency installation."""
import argparse,hashlib,json
from pathlib import Path

def inspect(path):
    path=Path(path)
    with path.open('rb') as handle:
        sha=hashlib.sha256()
        for chunk in iter(lambda:handle.read(1024*1024),b''):sha.update(chunk)
    result={'file':path.name,'sha256':sha.hexdigest(),'bytes':path.stat().st_size,'page_count':None,'method':'file_bytes','warnings':[]}
    if path.suffix.lower() in {'.png','.jpg','.jpeg','.webp','.gif'}:
        result.update(page_count=1,method='single_image_file')
    elif path.suffix.lower()=='.pdf':
        try:
            from pypdf import PdfReader
            reader=PdfReader(path)
            if reader.is_encrypted:raise ValueError('保護PDFは処理しません。')
            result.update(page_count=len(reader.pages),method='pypdf_metadata')
        except Exception as exc:
            result['warnings'].append('ページ数はネイティブ表示で確認してください。追加インストールしません: '+str(exc))
    else:
        result['warnings'].append('画像・PDF以外は図面のネイティブ視覚確認が別途必要です。')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input');a=p.parse_args()
    try:print(json.dumps(inspect(a.input),ensure_ascii=False,indent=2))
    except OSError as exc:p.exit(2,str(exc)+'\n')
