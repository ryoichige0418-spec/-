"""v0.3 evidence/coverage/approval checks before report generation.

This validates the consistency of supplied observations, not visual truth.
No OCR, geometric inference, authentication, or standards lookup is performed.
"""
import copy
import json
import re
from pathlib import Path
import check_dimensions
from runtime_catalog import load_json, recompile, scope_match, get_normative_entry

DEFINITE={'確認範囲で適合','指摘あり'}
ISSUES={'指摘あり','要確認','判定不能','規格照合待ち'}
PLACEHOLDERS={'','未確認','未取得','不明','TODO','null','None'}
SAFE_RULES={'RD-001','RD-002','RD-003','GN-001','RP-001','ST-001'}


def nonempty(value):
    return isinstance(value,str) and value.strip() not in PLACEHOLDERS


def page_number(value,count):
    return type(value) is int and 1<=value<=count


def observation_clear(source, coverage, count):
    if not isinstance(source,dict) or not page_number(source.get('page'),count):
        return False
    if not nonempty(source.get('location')) or not nonempty(source.get('raw')):
        return False
    exact=coverage.get((source['page'],source['location']))
    whole=coverage.get((source['page'],'ページ全体'))
    return bool(exact and exact['status']=='clear' and not (whole and whole['status']=='unreadable'))


def add_numeric_alerts(data,coverage,count):
    numeric=data.get('numeric_input')
    if numeric is None:
        return
    # Identity is one and the same full object; the CLI binds it to file bytes.
    if numeric.get('drawing')!=data['drawing']:
        raise ValueError('数値入力と原図の識別情報が一致しません。')
    for category in ('dimensions','fits','chains'):
        for item in numeric.get(category,[]):
            ev=item.get('evidence') or {}
            source={'page':ev.get('page'),'location':ev.get('region'),'raw':ev.get('raw')}
            if not observation_clear(source,coverage,count):
                if category=='dimensions':
                    item['read_status']='uncertain'
                elif category=='fits':
                    item['mating_confirmed']=False
                else:
                    item['relation_confirmed']=False
    calculated=check_dimensions.review(numeric)
    for row in calculated['chains']:
        if row.get('status')!='calculated' or row.get('classification') not in {'overlap_only','disjoint'}:
            continue
        target='数値入力 '+row['id']
        data['checks']=[c for c in data['checks'] if not (c.get('rule_id')==row['rule_id'] and c.get('target_id',c.get('target'))==target)]
        ev=row['evidence']
        data['checks'].append({'rule_id':row['rule_id'],'target_id':target,'target_label':'公差積上げ '+row['id'],
            'status':'要確認','reason':f"独立区間の最悪値積上げは {row['derived_minimum']}～{row['derived_maximum']} {row.get('unit','')}、要求区間は {row['target_minimum']}～{row['target_maximum']}。全組合せでの要求範囲内を保証できない。",
            'source':{'page':ev['page'],'location':ev['region'],'raw':ev['raw']},'read_status':'確認済み',
            'basis_type':'算術','importance':'中','action':'連鎖関係・独立性・要求の意味を原図で再確認し、成立する場合は寸法配分を見直す。',
            'automatically_added':True,'numeric_alert':True})


def _normative_valid(record,root,asof):
    try:
        get_normative_entry(record.get('evidence_id',''),root,asof)
        return True
    except (ValueError,KeyError,TypeError):
        return False


def prepare(data,root,previous=None):
    data=copy.deepcopy(data)
    if not isinstance(data,dict) or data.get('schema_version')!='3.0':
        raise ValueError('新規検図入力はschema_version=3.0です。v0.2の入力は移行手順に従ってください。')
    drawing=data.get('drawing',{})
    count=drawing.get('page_count')
    if type(count) is not int or not 1<=count<=1000:
        raise ValueError('drawing.page_countに原図で確認した総ページ数が必要です（1～1000）。')
    if not isinstance(drawing.get('sha256'),str) or not re.fullmatch(r'[0-9a-f]{64}',drawing['sha256']):
        raise ValueError('原図ファイルのSHA-256が必要です。CLIでは--drawing-fileから算出します。')
    for k in ('review_id','reviewed_on','mode'):
        if isinstance(data.get(k),str):data[k]=data[k].strip()
    scope=data.setdefault('review_scope',{})
    requested=scope.get('pages',list(range(1,count+1)))
    if not isinstance(requested,list) or not requested or len(set(requested))!=len(requested) or not all(page_number(p,count) for p in requested):
        raise ValueError('review_scope.pagesが不正です。')
    if data['mode']=='all' and set(requested)!=set(range(1,count+1)):
        raise ValueError('全体検図では全ページが対象です。限定する場合はfocusを使用してください。')
    scope['pages']=sorted(requested)
    coverage={}
    for row in data.setdefault('coverage',[]):
        if not page_number(row.get('page'),count) or not nonempty(row.get('region')):
            raise ValueError('確認範囲のページ・領域が不正です。')
        for k in ('region','status'):
            if isinstance(row.get(k),str):row[k]=row[k].strip()
        key=(row['page'],row['region'])
        if key in coverage:raise ValueError('同一ページ・領域の確認記録が重複しています。')
        if row.get('status') not in {'clear','partial','unreadable','unknown'}:
            raise ValueError('確認範囲の状態が不正です。')
        coverage[key]=row
    expected_coverage=data.get('expected_coverage',[])
    for item in expected_coverage:
        if not page_number(item.get('page'),count) or not nonempty(item.get('region')):
            raise ValueError('expected_coverageが不正です。')
        coverage.setdefault((item['page'],item['region']),{'page':item['page'],'region':item['region'],
            'status':'unknown','note':'予定した領域の確認記録がありません。','automatically_added':True})
    for page in range(1,count+1):
        coverage.setdefault((page,'ページ全体'),{'page':page,'region':'ページ全体','status':'unknown',
            'note':'ページ全体を観察した記録がありません。' if page in requested else '今回の重点検図の対象外。',
            'automatically_added':True,'outside_scope':page not in requested})
        whole=coverage[(page,'ページ全体')]
        # A clear whole page cannot conceal an explicitly unread child region.
        children=[r for (p,reg),r in coverage.items() if p==page and reg!='ページ全体']
        if whole['status']=='clear' and any(r['status']!='clear' for r in children):
            whole.update(status='partial',note=whole.get('note','')+' / 未確認の局所領域あり。')
    data['coverage']=list(coverage.values())
    general=load_json(root,'rules.json')
    general_ids={r['id'] for r in general['rules'] if r['enabled']}
    catalog=load_json(root,'rule-catalog.json')
    compiled=recompile(catalog,data['reviewed_on'],root=root)
    custom={r['rule_id']:r for r in compiled['rules']}
    all_ids=general_ids|set(custom)
    selected=all_ids
    if data['mode']=='focus':
        focus=scope.get('rule_ids')
        if not isinstance(focus,list) or not focus or not set(focus)<=all_ids:
            raise ValueError('重点検図の対象rule_idsを明示してください。')
        selected=set(focus)|SAFE_RULES
    scope['rule_ids']=sorted(selected)
    targets={'DRAWING':{'id':'DRAWING','label':'図面全体','rule_ids':sorted(selected)}}
    for target in data.get('targets',[]):
        tid=target.get('id')
        if not nonempty(tid) or tid in targets or not isinstance(target.get('rule_ids'),list) or not set(target['rule_ids'])<=all_ids:
            raise ValueError('targetsには重複しないIDと既知のrule_idsが必要です。DRAWINGは予約済みです。')
        targets[tid]=target
    expected={(rid,tid) for tid,t in targets.items() for rid in t['rule_ids'] if rid in selected}
    if not isinstance(data.get('checks'),list):raise ValueError('checksは配列です。')
    add_numeric_alerts(data,coverage,count)
    seen=set()
    for row in data['checks']:
        for k in ('rule_id','target_id','status','basis_type','read_status','importance'):
            if isinstance(row.get(k),str):row[k]=row[k].strip()
        rid,tid=row.get('rule_id'),row.get('target_id')
        if rid not in all_ids or not nonempty(tid) or (rid,tid) in seen:
            raise ValueError('ルールID・対象IDが未知又は重複しています。')
        if tid not in targets and not row.get('numeric_alert'):
            raise ValueError('対象をtargetsに登録してください: '+tid)
        if rid not in selected and row.get('status')!='未実施':
            raise ValueError('重点検図の指定範囲外に判定があります。範囲を拡張してから実行してください。')
        seen.add((rid,tid))
        row['target']=tid
        row.setdefault('target_label',targets.get(tid,{}).get('label',tid))
        status=row.get('status')
        src=row.get('source')
        if status in DEFINITE:
            if row.get('read_status')!='確認済み' or not observation_clear(src,coverage,count):
                raise ValueError('適合・指摘には同じページ領域の明瞭な原図根拠が必要です: '+rid+' / '+tid)
            if src.get('observation')=='absent':
                searched=src.get('searched_regions',[])
                if not searched or any(coverage.get((r.get('page'),r.get('region')),{}).get('status')!='clear' for r in searched):
                    raise ValueError('記載なしの判定には、検索した領域とその読取り確認が必要です。')
                if not row.get('exceptions_checked'):
                    raise ValueError('記載なしの判定には注記・参照仕様・例外の確認が必要です。')
        if status=='対象外' and (not nonempty(row.get('applicability_basis')) or row.get('read_status')!='確認済み'):
            raise ValueError('対象外には適用しない理由と確認記録が必要です。未読を対象外にしないでください。')
        if rid in custom:
            rule=custom[rid]
            applicable=scope_match(rule,drawing)
            row['rule_applicability']=applicable
            if status in DEFINITE:
                if rule['status'] not in {'usable','advisory'} or not rule.get('release_approved'):
                    raise ValueError('採用前・保留・参考のルールで確定判定できません。')
                if applicable!='applicable' or row.get('condition_verified') is not True or not nonempty(row.get('applicability_basis')):
                    raise ValueError('ルールの対象範囲・条件を確認できません。適用不明を違反にしないでください。')
                if row.get('exceptions_checked') is not True:
                    raise ValueError('社内ルールの例外確認が必要です。')
            if status=='対象外' and applicable!='not_applicable' and not nonempty(row.get('applicability_basis')):
                raise ValueError('対象外とする根拠が必要です。')
        if row.get('basis_type')=='規格本文照合':
            ids=row.get('normative_evidence_ids',[])
            if not ids:
                if status in DEFINITE:raise ValueError('規格本文照合には採用済み条項IDが必要です。')
                row['basis_type']='一般確認観点'
                row['reference']='規格本文照合は未実施。'
            else:
                entries=[get_normative_entry(eid,root,data['reviewed_on']) for eid in ids]
                if status in DEFINITE and (row.get('condition_verified') is not True or not nonempty(row.get('applicability_basis')) or row.get('exceptions_checked') is not True):
                    raise ValueError('規格条項の適用条件・例外の確認が必要です。')
                if any(rid not in e.get('rule_ids',[]) for e in entries):
                    raise ValueError('規格条項IDと確認ルールが対応していません。')
                row['standard_evidence']={k:entries[0][k] for k in ('standard','edition','clause','source_file','locator','applicability')}
                row['reference']=' / '.join(f"{e['standard']}:{e['edition']} {e['clause']} ({e['evidence_id']})" for e in entries)
        if row.get('basis_type')=='社内規則照合' and status in DEFINITE and rid not in custom:
            raise ValueError('社内規則の確定判定は承認されたCORPルールIDで記録してください。')
        if (rid,tid) not in expected and rid in selected:
            expected.add((rid,tid))
    for rid,tid in sorted(expected-seen):
        state=custom.get(rid,{}).get('status')
        blocked=state=='pending'
        data['checks'].append({'rule_id':rid,'target':tid,'target_id':tid,'target_label':targets[tid].get('label',tid),
            'status':'要確認' if blocked else '未実施','reason':'採用・適用待ち: '+' / '.join(custom[rid].get('blockers',[])) if blocked else 'このルール×対象の確認記録がありません。',
            'source':{'page':None,'location':'未確認','raw':'未取得'},'read_status':'読取り不可','basis_type':'一般確認観点',
            'importance':'未評価','action':'原図とルールの適用条件を確認する。','automatically_added':True})
    if previous is not None:
        for res in data.get('resolutions',[]):
            if res.get('result')=='解消':
                kind=res.get('resolution_basis')
                if kind not in {'drawing_change','interpretation_correction','rule_change'}:
                    raise ValueError('解消には図面変更・誤指摘訂正・ルール変更の区分が必要です。')
                if kind=='drawing_change' and previous.get('drawing',{}).get('sha256')==drawing['sha256']:
                    raise ValueError('原図のバイト列が同じです。図面変更による解消として記録できません。')
                if kind!='drawing_change' and not nonempty(res.get('reviewer_record')):
                    raise ValueError('誤指摘訂正・ルール変更には確認者の承認記録が必要です。')
                if not observation_clear(res.get('source'),coverage,count):
                    raise ValueError('解消の根拠領域が確認できません。')
    data['schema_version']='2.0'
    meta={'guard_version':'0.3.0','input_schema':'3.0','review_scope':scope,
        'targets':list(targets.values()),'expected_checks':[{'rule_id':r,'target_id':t} for r,t in sorted(expected)],
        'inventory_confirmed':data.get('inventory_confirmed') is True,
        'inventory_basis':data.get('inventory_basis','形体の抽出完全性は未確認。'),
        'registered_normative_entries':len(load_json(root,'normative-evidence.json').get('entries',[])),
        'approved_normative_entries':sum(1 for rec in load_json(root,'rule-approvals.json').get('normative_approvals',[]) if _normative_valid(rec,root,data['reviewed_on'])),
        'source_truth_limit':'図面の視覚認識・転記の正しさと人の承認者本人性はこのコードでは検証しない。'}
    return data,meta


def finish(report,meta):
    report.update(meta)
    expected={(r['rule_id'],r['target_id']) for r in meta['expected_checks']}
    rows=[r for r in report['checks'] if (r['rule_id'],r['target']) in expected]
    unread=sum(r['status']!='clear' for r in report['coverage'] if r['page'] in meta['review_scope']['pages'])
    unexecuted=sum(r['status']=='未実施' for r in rows)
    pending=sum(r['status'] in {'要確認','判定不能','規格照合待ち'} for r in rows)
    missing=unread>0 or unexecuted>0 or pending>0 or not meta['inventory_confirmed']
    report['summary'].update(expected_check_count=len(expected),unexecuted_expected_count=unexecuted,
        pending_expected_count=pending,unread_in_requested_scope=unread,inventory_confirmed=meta['inventory_confirmed'],
        adopted_normative_entries=meta['approved_normative_entries'],
        overall='要対応・要確認あり' if report['findings'] else ('確認範囲の指摘なし（未確認あり）' if missing else '確認範囲の指摘なし'))
    report['scope']=f"{report['summary']['overall']}。対象内の未実施 {unexecuted} 件、未読領域 {unread} 件。JIS全適合・製作可否・出図承認を保証しない。認識と転記は入力記録に依存。"
    return report
