"""Prepare a reviewable candidate catalog; never adopt or deploy it."""
import argparse,json
from pathlib import Path
from candidate_merge import merge
from package_skill import digest


def propose(catalog,manifest,asof):
    candidate,delta=merge(catalog,manifest,asof)
    # 'usable' here means extraction/context checks passed, not formal adoption.
    request={'schema_version':'1.0','release_id':None,'catalog_digest':digest(candidate),'normative_digest':None,
        'approved_rules':[],'normative_approvals':[],
        'candidate_rule_ids':[r['rule_id'] for r in candidate['rules'] if r['status'] in {'usable','advisory'}],
        'warning':'候補の抽出品質と採用承認は別。本人確認・権限確認・正式承認は組織の承認経路で行う。'}
    return candidate,delta,request


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--catalog',required=True);p.add_argument('--manifest',required=True)
    p.add_argument('--as-of',required=True);p.add_argument('--out-dir',required=True)
    a=p.parse_args()
    try:
        out=Path(a.out_dir);out.mkdir(parents=True,exist_ok=False)
        c,d,r=propose(json.loads(Path(a.catalog).read_text(encoding='utf-8-sig')),
                      json.loads(Path(a.manifest).read_text(encoding='utf-8-sig')),a.as_of)
        for name,obj in [('candidate-catalog.json',c),('change-report.json',d),('approval-request.json',r)]:
            (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'candidate':str(out),'approval':'未承認','rules':len(c['rules'])},ensure_ascii=False))
    except (ValueError,OSError,KeyError,TypeError) as exc:p.exit(2,'候補作成エラー: '+str(exc)+'\n')

if __name__=='__main__':main()
