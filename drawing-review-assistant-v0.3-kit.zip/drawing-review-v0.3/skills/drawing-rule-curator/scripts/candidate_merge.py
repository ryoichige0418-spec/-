"""Merge changed sources with the embedded catalog and emit ONE full skill ZIP."""
import argparse
import copy
import json
import shutil
import tempfile
from pathlib import Path
from rule_engine import BuildError, compile_manifest, comparison, iso_date, objects, text, rule_lines
from package_skill import package, digest

ROOT = Path(__file__).resolve().parents[1]


def refs(rule):
    return rule['evidence'] + rule['scope']['evidence']


def raw_candidate(rule):
    fields = ('key', 'title', 'classification', 'requirement', 'check_procedure',
              'fail_condition', 'unknown_handling', 'exceptions', 'context_verified',
              'evidence', 'scope', 'conflicts_with')
    return {key: copy.deepcopy(rule[key]) for key in fields}


def recompile(catalog, asof):
    """Recheck dates, source validity, and conflict guards at every review."""
    if not isinstance(catalog, dict) or catalog.get('schema_version') != '1.0':
        raise BuildError('内包台帳の形式が不正です。')
    compiled = compile_manifest({'schema_version': '1.0',
        'package': {**catalog['package'], 'generated_on': asof},
        'sources': catalog['sources'], 'candidates': [raw_candidate(r) for r in catalog['rules']]})
    comparison(compiled, catalog)
    old = {r['key']: r for r in catalog['rules']}
    for rule in compiled['rules']:
        for field in ('lifecycle', 'lifecycle_reason', 'retirement_evidence', 'legacy_rule_ids'):
            if field in old[rule['key']]:
                rule[field] = copy.deepcopy(old[rule['key']][field])
        if rule.get('lifecycle') in {'removal_candidate', 'retired'}:
            rule['status'] = 'pending'
            rule['blockers'] = list(dict.fromkeys(rule['blockers'] + [rule['lifecycle_reason']]))
    return compiled


def merge(previous, incoming, asof):
    iso_date(asof)
    previous = copy.deepcopy(previous)
    incoming = copy.deepcopy(incoming)
    recompile(previous, asof)  # Validate catalog before using or modifying it.
    if asof < previous['package']['generated_on']:
        raise BuildError('前回の生成日より前の日付では更新できません。')
    if not isinstance(incoming, dict) or incoming.get('schema_version') != '1.0':
        raise BuildError('schema_version=1.0が必要です。')
    new_sources = objects(incoming, 'sources')
    candidates = objects(incoming, 'candidates')
    settings = incoming.get('update', {})
    if not isinstance(settings, dict):
        raise BuildError('updateはオブジェクトです。')
    replacements = objects({'replacements': settings.get('replacements', [])}, 'replacements')
    retirements = objects({'retirements': settings.get('retirements', [])}, 'retirements')
    sources = {s['id']: s for s in previous['sources']}
    new_index = {}
    for source in new_sources:
        sid = text(source, 'id')
        if sid in new_index:
            raise BuildError('今回の資料IDが重複しています。')
        new_index[sid] = source
        if sid in sources and digest(source) != digest(sources[sid]):
            raise BuildError('同じ資料IDの内容は変更できません。改訂資料に新しいIDを付けてください。')
    replaced = set()
    for item in replacements:
        old, new = text(item, 'old_source_id'), text(item, 'new_source_id')
        text(item, 'basis')
        if old not in sources or new not in new_index or old == new or old in replaced:
            raise BuildError('資料差替えの対応が不正又は重複しています。')
        replaced.add(old)
        sources[old]['state'] = 'superseded'
    # A familiar title on a new revision must not silently coexist with the old source.
    distinct = {text(x, 'source_id'): text(x, 'basis') for x in
                objects({'items': settings.get('independent_sources', [])}, 'items')}
    if set(distinct) - new_index.keys():
        raise BuildError('独立資料の指定先が今回の資料にありません。')
    for sid, source in new_index.items():
        for old in previous['sources']:
            if old['id'] != sid and old['id'] not in replaced and old['state'] == 'current' and old['title'] == source.get('title') and sid not in distinct:
                raise BuildError('同名の現行資料があります。差替え対応か、別文書である根拠を記録してください。')
    sources.update(new_index)
    old_rules = {r['key']: r for r in previous['rules']}
    combined = {key: raw_candidate(rule) for key, rule in old_rules.items()}
    new_keys = set()
    for candidate in candidates:
        key = text(candidate, 'key')
        if key in new_keys:
            raise BuildError('今回のルールkeyが重複しています。')
        new_keys.add(key)
        combined[key] = candidate
    lifecycle = {key: {field: copy.deepcopy(rule[field]) for field in
                 ('lifecycle', 'lifecycle_reason', 'retirement_evidence', 'legacy_rule_ids') if field in rule}
                 for key, rule in old_rules.items()}
    removed_candidates, carried = [], []
    for key, rule in old_rules.items():
        if key in new_keys:
            lifecycle[key] = {**lifecycle[key], 'lifecycle': 'active'}
            lifecycle[key].pop('lifecycle_reason', None)
            lifecycle[key].pop('retirement_evidence', None)
        elif lifecycle[key].get('lifecycle') != 'retired' and any(r['source_id'] in replaced for r in refs(rule)):
            lifecycle[key] = {**lifecycle[key], 'lifecycle': 'removal_candidate',
                              'lifecycle_reason': '改訂資料で再抽出されなかった条件。廃止又は抽出漏れの確認が必要。'}
            removed_candidates.append(key)
        else:
            carried.append(key)
    retired = set()
    for retirement in retirements:
        key = text(retirement, 'key')
        reason = text(retirement, 'reason')
        if key not in old_rules or key in new_keys or key in retired:
            raise BuildError('廃止対象が未知、重複、又は今回の新規候補と競合しています。')
        evidence = objects(retirement, 'evidence')
        # Use the same evidence/authority/date guards as mandatory rule creation.
        proof = raw_candidate(old_rules[key])
        proof.update(classification='requirement', context_verified=True, evidence=evidence, conflicts_with=[])
        proof['scope'] = {'level': 'company', 'targets': [], 'condition': reason, 'confirmed': True, 'evidence': evidence}
        check = compile_manifest({'schema_version': '1.0', 'package': {**previous['package'], 'generated_on': asof},
            'sources': list(sources.values()), 'candidates': [proof]})['rules'][0]
        if check['status'] != 'usable':
            raise BuildError('廃止の根拠が確定していません: ' + ', '.join(check['blockers']))
        lifecycle[key] = {**lifecycle[key], 'lifecycle': 'retired', 'lifecycle_reason': '明示された廃止: ' + reason,
                          'retirement_evidence': check['evidence']}
        retired.add(key)
    all_retired = {k for k, item in lifecycle.items() if item.get('lifecycle') == 'retired'}
    for candidate in combined.values():
        candidate['conflicts_with'] = [] if candidate['key'] in all_retired else [k for k in candidate['conflicts_with'] if k not in all_retired]
    version = previous['package']['version'].split('.')
    version[-1] = str(int(version[-1]) + 1)
    result = compile_manifest({'schema_version': '1.0',
        'package': {**previous['package'], 'version': '.'.join(version), 'generated_on': asof},
        'sources': list(sources.values()), 'candidates': list(combined.values())})
    for rule in result['rules']:
        rule.update(lifecycle.get(rule['key'], {'lifecycle': 'active'}))
    result = recompile(result, asof)
    result['builder_version'] = '0.2.0'
    delta = comparison(result, previous)
    delta.update(carried_keys=carried, removal_candidates=removed_candidates,
                 retired_keys=sorted(retired), replaced_source_ids=sorted(replaced),
                 previous_version=previous['package']['version'], version=result['package']['version'])
    return result, delta

