#!/usr/bin/env python3
"""Extract traceable text blocks; retain gaps needing Copilot visual reading.

DOCX/PPTX/TXT: standard library. PDF: optional preinstalled pypdf; never installs
packages. Does not OCR images, interpret engineering symbols, or infer rules.
"""
import argparse
import hashlib
import json
import posixpath
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

NS = {
    'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
    'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'pr': 'http://schemas.openxmlformats.org/package/2006/relationships',
}


def q(prefix, name):
    return '{' + NS[prefix] + '}' + name


def xml(archive, part):
    info = archive.getinfo(part)
    if info.file_size > 16 * 1024 * 1024:
        raise ValueError('XML部品が16MiBを超えるため部分抽出を中止しました。')
    return ET.fromstring(archive.read(part))


def words(node, family):
    if family == 'w':
        paras = list(node.iter(q('w', 'p')))
        if node.tag == q('w', 'p'):
            paras = [node]
        return '\n'.join(''.join(n.text or '' for n in p.iter() if n.tag in {q('w','t'), q('w','delText')}) for p in paras).strip()
    return '\n'.join(''.join(n.text or '' for n in p.iter(q('a', 't'))) for p in node.iter(q('a', 'p'))).strip()


def add(source, locator, content, channel='body', method='xml', read_status='clear'):
    if content.strip():
        source['segments'].append({'id': 'B' + str(len(source['segments']) + 1).zfill(4), 'locator': locator,
                                   'text': content.strip(), 'read_status': read_status, 'channel': channel, 'method': method})


def word_table(node):
    lines = []
    for row_index, row in enumerate(node.findall('w:tr', NS), 1):
        cells = []
        for col_index, cell in enumerate(row.findall('w:tc', NS), 1):
            props = cell.find('w:tcPr', NS)
            attrs = []
            if props is not None:
                span = props.find('w:gridSpan', NS)
                merge = props.find('w:vMerge', NS)
                if span is not None:
                    attrs.append('横結合=' + span.get(q('w', 'val'), '?'))
                if merge is not None:
                    attrs.append('縦結合=' + merge.get(q('w', 'val'), '継続'))
            cells.append(f"列{col_index}{'[' + ','.join(attrs) + ']' if attrs else ''}: {words(cell,'w')}")
        lines.append(f"行{row_index} | " + ' | '.join(cells))
    return '\n'.join(lines)


def read_docx(path, source):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        parts = ['word/document.xml'] + sorted(p for p in names if re.fullmatch(r'word/(?:header|footer)\d+\.xml', p))
        for part in parts:
            root = xml(archive, part)
            body = root.find('w:body', NS) if part == 'word/document.xml' else root
            if body is None:
                raise ValueError('本文を取得できません。')
            for idx, node in enumerate(list(body), 1):
                if node.tag not in {q('w','p'), q('w','tbl')}:
                    if node.tag != q('w', 'sectPr'):
                        source['unread_parts'].append(f'{part}/要素{idx}: 本文構造の追加確認が必要')
                    continue
                tracked = any(n.tag in {q('w','ins'), q('w','del'), q('w','moveFrom'), q('w','moveTo')} for n in node.iter())
                channel = 'revision' if tracked else ('table' if node.tag == q('w','tbl') else 'body')
                content = word_table(node) if node.tag == q('w','tbl') else words(node,'w')
                add(source, f'{part} / 本文要素{idx}（ページ番号は未確定）', content, channel, read_status='uncertain' if tracked else 'clear')
                if tracked:
                    source['unread_parts'].append(f'{part}/要素{idx}: 変更履歴の採用状態を確認')
                if any(n.tag in {q('w','drawing'), q('w','pict'), q('w','object')} for n in node.iter()):
                    source['unread_parts'].append(f'{part}/要素{idx}: 図・テキストボックス・埋込物の視覚確認')
        for part in names:
            if part in {'word/footnotes.xml','word/endnotes.xml','word/comments.xml'}:
                root = xml(archive,part)
                add(source, part, words(root,'w'), 'notes')
                source['unread_parts'].append(part + ': 注釈の対象・適用関係を確認')


def relationships(archive, part):
    result = {}
    if part not in archive.namelist():
        return result
    for rel in xml(archive,part):
        if rel.get('TargetMode') != 'External':
            result[rel.get('Id')] = (rel.get('Target',''), rel.get('Type',''))
    return result


def resolve_part(base, target):
    path = posixpath.normpath(posixpath.join(base, target.lstrip('/'))) if not target.startswith('/') else target.lstrip('/')
    if path.startswith('../') or path == '..':
        raise ValueError('不正なOffice内部参照。')
    return path


def slide_table(node):
    lines=[]
    for row_index,row in enumerate(node.findall('a:tr', NS),1):
        cells=[]
        for col_index,cell in enumerate(row.findall('a:tc', NS),1):
            merges=','.join(f'{key}={cell.get(key)}' for key in ('gridSpan','rowSpan','hMerge','vMerge') if cell.get(key))
            cells.append(f"列{col_index}{'['+merges+']' if merges else ''}: {words(cell,'a')}")
        lines.append(f'行{row_index} | ' + ' | '.join(cells))
    return '\n'.join(lines)


def read_pptx(path, source):
    with zipfile.ZipFile(path) as archive:
        pres=xml(archive,'ppt/presentation.xml')
        rels=relationships(archive,'ppt/_rels/presentation.xml.rels')
        ids=pres.findall('p:sldIdLst/p:sldId', NS)
        for index,sid in enumerate(ids,1):
            rid=sid.get(q('r','id'))
            if rid not in rels:
                raise ValueError('スライドの参照を解決できません。')
            part=resolve_part('ppt',rels[rid][0])
            root=xml(archive,part)
            hidden=root.get('show') in {'0', 'false'}
            tree=root.find('p:cSld/p:spTree', NS)
            if tree is None:
                source['unread_parts'].append(f'スライド{index}: 図形ツリー未取得')
                continue
            for shape_index,node in enumerate(list(tree),1):
                table=node.find('.//a:tbl',NS)
                content=slide_table(table) if table is not None else words(node,'a')
                channel='hidden' if hidden else ('table' if table is not None else 'body')
                add(source,f'スライド{index} / 要素{shape_index}',content,channel)
            # Arrows, colors, layout and images may carry meaning even without pictures.
            source['unread_parts'].append(f'スライド{index}: 配置・矢印・色・図の意味を視覚確認' + ('（非表示）' if hidden else ''))
            folder=posixpath.dirname(part)
            srels=relationships(archive,folder+'/_rels/'+posixpath.basename(part)+'.rels')
            for target,kind in srels.values():
                if kind.endswith('/notesSlide'):
                    notes=xml(archive,resolve_part(folder,target))
                    add(source,f'スライド{index} / 発表者ノート',words(notes,'a'),'notes')
                    source['unread_parts'].append(f'スライド{index}: 発表者ノートの位置付けを確認')


def extract(path):
    raw=path.read_bytes()
    digest=hashlib.sha256(raw).hexdigest()
    source={'id':'SRC-'+digest[:12].upper(),'file':path.name,'title':path.stem,'sha256':digest,
            'revision':None,'role':'unknown','state':'unknown','metadata_basis':None,'url':None,
            'effective_from':None,'effective_to':None,'coverage':'unknown','unread_parts':[],'segments':[]}
    suffix=path.suffix.lower()
    try:
        if len(raw)>100*1024*1024:
            raise ValueError('100MiBを超えます。分割又はネイティブ表示で確認してください。')
        if suffix=='.docx':
            read_docx(path,source)
        elif suffix=='.pptx':
            read_pptx(path,source)
        elif suffix in {'.txt','.md','.utf8'}:
            content=raw.decode('utf-8-sig')
            lines=content.splitlines()
            for start in range(0,len(lines),40):
                add(source,f'行{start+1}〜{min(start+40,len(lines))}','\n'.join(lines[start:start+40]),method='native')
        elif suffix=='.pdf':
            try:
                from pypdf import PdfReader
            except ImportError:
                raise ValueError('pypdf未導入。追加インストールせずCopilotのPDF表示で確認してください。')
            try:
                reader=PdfReader(path)
                if reader.is_encrypted:
                    raise ValueError('保護PDF。保護を解除せず利用可能な参照方法で確認してください。')
                for idx,page in enumerate(reader.pages,1):
                    add(source,f'ページ{idx}',page.extract_text() or '',method='pdf_text')
                    source['unread_parts'].append(f'ページ{idx}: 図形・記号・文字と形体の対応を視覚確認')
            except Exception as exc:
                # Third-party PDF parsers use several exception families.
                raise ValueError('PDF抽出未完了: ' + str(exc)) from exc
        else:
            source['unread_parts'].append('画像又は未対応形式。Copilotで視覚確認し、位置付きの転記を追加。旧Office/CADは読める形式を用意。')
    except (ValueError,KeyError,ET.ParseError,zipfile.BadZipFile,UnicodeError) as exc:
        source['unread_parts'].append('抽出できなかった部分: '+str(exc))
    source['coverage']='partial' if source['segments'] else 'unreadable'
    # Never infer completeness, authority or current revision from extraction alone.
    source['unread_parts'].append('資料全体の文脈・適用範囲・版・有効性は未確認')
    source['unread_parts']=list(dict.fromkeys(source['unread_parts']))
    return source


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('inputs',nargs='+')
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    output=Path(args.output)
    if output.exists() or output.resolve() in [Path(p).resolve() for p in args.inputs]:
        parser.error('出力は未使用のパスを指定してください。')
    try:
        sources=[]
        seen={}
        for value in args.inputs:
            source=extract(Path(value))
            if source['sha256'] not in seen:
                sources.append(source)
                seen[source['sha256']] = source
            else:
                seen[source['sha256']].setdefault('file_aliases', []).append(source['file'])
        output.parent.mkdir(parents=True,exist_ok=True)
        output.write_text(json.dumps({'schema_version':'1.0','sources':sources},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'output':str(output),'sources':len(sources),'segments':sum(len(s['segments']) for s in sources)},ensure_ascii=False))
    except OSError as exc:
        parser.exit(2,'読取りエラー: '+str(exc)+'\n')


if __name__=='__main__':
    main()
