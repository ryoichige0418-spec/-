# 図面検図エージェント 再設計キット v0.3
作成・公式情報確認: 2026-10-06

## 最初に読むもの
`DESIGN_REPORT.html` が監査結果・日常機能・構成・導入手順をまとめた単独で開ける日本語レポートです。外部JavaScript・フォント・CDNは不要です。

## Agent Builderへの初期登録
1. テナントのSkills利用条件を確認する。現時点ではFrontierプレビューであり、Information Barriers等の制約がある。
2. 新しい検証用エージェントに `agent-config/review-instructions.txt` とdescriptionを設定する。
3. Skillsへ `upload/drawing-review-assistant-v0.3.zip` をそのまま追加する。**本キット全体のZIPをアップロードしない。SKILL.md単体でもない。**
4. 「Create documents, charts, and code」を有効にする。画像生成と一般Web検索は本用途では無効を推奨する。
5. 初期状態では埋込みKnowledgeを登録しない。Skillsとの併用は現行プレビューの制約がある。原図は実行時の添付資料として扱う。
6. 匿名化した部品図で `validation/COPILOT_ACCEPTANCE.md` を実施してから限定利用する。

管理用スキル `upload/drawing-rule-curator-v0.3.zip` は必要になった段階で別の管理用エージェントに追加する。日常検図への同時登録は推奨しない。

## 今回の実装範囲
一般27確認観点と明示値の算術を維持。v0.3で原図ハッシュ、ページ/領域の未確認管理、対象ID、ルール×対象の未実施管理、採用承認/適用条件、規格条項ID、計算結果の指摘連携、再検図の解消根拠を追加した。
JIS本文、公差表、実在する社内ルールは同梱していない。規格根拠と採用承認は0件から開始する。「JIS完全対応」「製作可能」「出図承認済み」の意味ではない。

## ローカル検証
Python 3.10以降。標準ライブラリで主要処理を実行する。PDFのページ数取得はpypdfが既に存在する場合のみ利用し、なければネイティブ表示で確認する。Copilot環境へ追加インストールしない。

```sh
python -m unittest discover -s validation -p test_v03.py -v
python skills/drawing-review-assistant/scripts/review_report.py create examples/synthetic-review.json --drawing-file examples/SYNTHETIC-DEMO.txt --out demo-report.xlsx
python skills/drawing-review-assistant/scripts/review_report.py read demo-report.xlsx --out demo-roundtrip.json
```

`synthetic-review.json` は原図認識を含まない架空の転記テストです。実図面の読取り精度を示しません。出力先は未使用の名前を指定します。

## ルール追加
管理用スキルで候補を作り、要求元責任者の承認後、`tools/prepare_approval_request.py` と `tools/build_release.py` の管理者手順を使う。手順は `design/RULE_GOVERNANCE.md` を参照。これらのツールは承認者本人性を認証せず、Microsoftテナントへ配布もしない。

## Copilot Studio
`studio/IMPLEMENTATION_BLUEPRINT.md` は設計書であり、インポート可能なSolution ZIPではない。Skills ZIPをStudioへそのままインポートできるとは想定しない。認証付き検索・サーバー側検証・承認・記録をTopics/Agent Flows/サービスへ移す。

## 検証結果と未実施
v0.2既存96件を原環境のコードに対して再実行して合格。v0.3追加48件の合成入力による契約・回帰試験も合格。実図面の認識精度、Microsoftテナントでのインストールと実行、Excelデスクトップで編集した際の再取込みは未検証。ローカルでの生成・読戻し試験は実施済み。

入力・根拠・承認記録を人が虚偽入力した場合の真偽はコードで検証できない。Skillの指示が必ず実行される保証もない。プロンプトとローカル検証はアクセス制御ではなく、本番の承認・配布・サービス認可は組織側で設計する。
