"""Synthetic contract tests: these do NOT measure drawing recognition accuracy."""
import copy,hashlib,json,shutil,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SKILL=ROOT/'skills/drawing-review-assistant'
sys.path.insert(0,str(SKILL/'scripts'))
import review_report as report
import runtime_catalog as runtime
import guardrails
import rule_engine
from package_skill import digest


def base(status='指摘あり'):
    return {'schema_version':'3.0','review_id':'SYNTHETIC-001','reviewed_on':'2026-10-06','mode':'all',
        'drawing':{'file':'SYNTHETIC.txt','number':'TEST-001','revision':'A','page_count':1,'sha256':'a'*64,'product':'ユニットA'},
        'inventory_confirmed':False,'targets':[{'id':'MAT','label':'材質欄','rule_ids':['GN-003']}],
        'checks':[{'rule_id':'GN-003','target_id':'MAT','status':status,'reason':'架空入力の確認記録。',
          'source':{'page':1,'location':'表題欄','raw':'材質: SPEC-Xによる'},'read_status':'確認済み',
          'basis_type':'一般確認観点','importance':'中','action':'材料仕様の参照先を確認する。'}],
        'coverage':[{'page':1,'region':'ページ全体','status':'clear','note':'合成転記のテスト。実画像の確認はしていない。'},
                    {'page':1,'region':'表題欄','status':'clear','note':'合成転記のテスト。'}]}


def numeric(data,target='30',tol='0.15'):
    drawing=data['drawing']
    dimensions=[]
    for name,n,t in [('A','10','0.1'),('B','20','0.1'),('T',target,tol)]:
        dimensions.append({'id':name,'read_status':'clear','kind':'size','unit':'mm','form':'symmetric','nominal':n,'tolerance':t,
            'evidence':{'page':1,'region':'表題欄','raw':name+'='+n+'±'+t}})
    data['numeric_input']={'schema_version':'1.0','drawing':copy.deepcopy(drawing),'dimensions':dimensions,'fits':[],
        'chains':[{'id':'C01','target_id':'T','relation_confirmed':True,'independent_intervals':True,
         'terms':[{'dimension_id':'A','sign':1},{'dimension_id':'B','sign':1}],
         'evidence':{'page':1,'region':'表題欄','raw':'T=A+B。独立区間とする架空入力。'}}]}
    return data


def custom_root(folder,approved=True):
    root=Path(folder)/'skill';shutil.copytree(SKILL,root)
    manifest=json.loads((ROOT/'validation/fixtures/sample-manifest.json').read_text())
    manifest['package']['name']='drawing-review-assistant'
    catalog=rule_engine.compile_manifest(manifest)
    (root/'references/rule-catalog.json').write_text(json.dumps(catalog,ensure_ascii=False))
    approval=runtime.load_json(root,'rule-approvals.json')
    approval['catalog_digest']=digest(catalog)
    rule=next(r for r in catalog['rules'] if r['key']=='material.field')
    if approved:
        approval['approved_rules']=[{'rule_id':rule['rule_id'],'rule_digest':digest(runtime.raw_candidate(rule)),
            'approved_by':'架空のテスト承認者','approved_on':'2026-10-05','approval_record':'SYNTHETIC-APPROVAL'}]
    (root/'references/rule-approvals.json').write_text(json.dumps(approval,ensure_ascii=False))
    data=base('確認範囲で適合');rid=rule['rule_id']
    data['targets'][0]['rule_ids']=[rid]
    data['checks'][0].update(rule_id=rid,basis_type='社内規則照合',reference='架空標準STD S1',condition_verified=True,
                             applicability_basis='ユニットAの切削部品であるとする架空入力',exceptions_checked=True)
    return root,data


def normative_root(folder):
    root=Path(folder)/'skill';shutil.copytree(SKILL,root)
    entry={'evidence_id':'SYNTHETIC-CLAUSE','standard':'架空規格（JISではない）','edition':'1','clause':'TEST-1',
        'source_file':'fiction.txt','locator':'架空項目1','source_sha256':'b'*64,
        'requirement':'これはテスト用の架空要求。','applicability':'架空のテストのみ',
        'rule_ids':['GN-003'],'content_kind':'verified_requirement','rights_confirmed':True}
    registry={'schema_version':'1.0','entries':[entry]}
    approval=runtime.load_json(root,'rule-approvals.json')
    approval.update(normative_digest=digest(registry),normative_approvals=[{'evidence_id':entry['evidence_id'],
        'evidence_digest':digest(entry),'approved_by':'架空のテスト承認者','approved_on':'2026-10-05','approval_record':'SYNTHETIC-APPROVAL'}])
    for name,obj in [('normative-evidence.json',registry),('rule-approvals.json',approval)]:
        (root/'references'/name).write_text(json.dumps(obj,ensure_ascii=False))
    data=base('確認範囲で適合')
    data['checks'][0].update(basis_type='規格本文照合',normative_evidence_ids=[entry['evidence_id']],
        condition_verified=True,applicability_basis='合成試験データ',exceptions_checked=True)
    return root,data


class GuardTests(unittest.TestCase):
    def norm(self,d):return report.normalize(d,SKILL)
    def test_01_whitespace_is_canonical(self):
        r=self.norm(base(' 指摘あり '));self.assertEqual(r['summary']['finding_count'],1)
    def test_02_clear_local_pass(self):
        r=self.norm(base('確認範囲で適合'));self.assertEqual(r['checks'][0]['status'],'確認範囲で適合')
    def test_03_missing_pages_visible(self):
        d=base();d['drawing']['page_count']=3;r=self.norm(d)
        self.assertEqual(r['summary']['unread_in_requested_scope'],2)
    def test_04_unread_region_cannot_pass(self):
        d=base('確認範囲で適合');d['coverage'][1]['status']='unreadable'
        with self.assertRaises(ValueError):self.norm(d)
    def test_05_unknown_page_cannot_pass(self):
        d=base('確認範囲で適合');d['checks'][0]['source']['page']=None
        with self.assertRaises(ValueError):self.norm(d)
    def test_06_placeholder_raw_cannot_pass(self):
        d=base('確認範囲で適合');d['checks'][0]['source']['raw']='未取得'
        with self.assertRaises(ValueError):self.norm(d)
    def test_07_whole_unread_cannot_pass(self):
        d=base('確認範囲で適合');d['coverage'][0]['status']='unreadable'
        with self.assertRaises(ValueError):self.norm(d)
    def test_08_partial_whole_allows_clear_local(self):
        d=base('確認範囲で適合');d['coverage'][0]['status']='partial'
        self.assertEqual(self.norm(d)['checks'][0]['status'],'確認範囲で適合')
    def test_09_absence_needs_search(self):
        d=base();d['checks'][0]['source']['observation']='absent'
        with self.assertRaises(ValueError):self.norm(d)
    def test_10_absence_with_evidence(self):
        d=base();d['checks'][0]['source'].update(observation='absent',searched_regions=[{'page':1,'region':'表題欄'}])
        d['checks'][0]['exceptions_checked']=True;self.norm(d)
    def test_11_absence_unread_search_reject(self):
        d=base();d['checks'][0]['source'].update(observation='absent',searched_regions=[{'page':1,'region':'ない領域'}])
        d['checks'][0]['exceptions_checked']=True
        with self.assertRaises(ValueError):self.norm(d)
    def test_12_chain_overlap_in_findings(self):
        d=numeric(base());d['checks']=[];r=self.norm(d)
        self.assertTrue(any(x.get('numeric_alert') for x in r['findings']))
    def test_13_chain_disjoint_in_findings(self):
        d=numeric(base(),target='31');d['checks']=[];r=self.norm(d)
        self.assertEqual(r['numeric']['chains'][0]['classification'],'disjoint')
        self.assertTrue(any(x.get('numeric_alert') for x in r['findings']))
    def test_14_chain_contained_no_alert(self):
        d=numeric(base(),tol='0.5');d['checks']=[];r=self.norm(d)
        self.assertFalse(any(x.get('numeric_alert') for x in r['findings']))
    def test_15_uncertain_numeric_not_definite(self):
        d=numeric(base());d['checks']=[];d['coverage'][1]['status']='unreadable';r=self.norm(d)
        self.assertNotEqual(r['numeric']['chains'][0]['status'],'calculated')
    def test_16_rule_target_missing_is_unexecuted(self):
        d=base();d['targets'].append({'id':'MAT2','label':'別の材質欄','rule_ids':['GN-003']});r=self.norm(d)
        self.assertTrue(any(c['target']=='MAT2' and c['status']=='未実施' for c in r['checks']))
    def test_17_duplicate_target_rejected(self):
        d=base();d['targets'].append(copy.deepcopy(d['targets'][0]))
        with self.assertRaises(ValueError):self.norm(d)
    def test_18_target_not_registered_rejected(self):
        d=base();d['checks'][0]['target_id']='UNKNOWN'
        with self.assertRaises(ValueError):self.norm(d)
    def test_19_page_count_required(self):
        d=base();d['drawing'].pop('page_count')
        with self.assertRaises(ValueError):self.norm(d)
    def test_20_hash_required(self):
        d=base();d['drawing'].pop('sha256')
        with self.assertRaises(ValueError):self.norm(d)
    def test_21_full_mode_cannot_skip_page(self):
        d=base();d['drawing']['page_count']=3;d['review_scope']={'pages':[1]}
        with self.assertRaises(ValueError):self.norm(d)
    def test_22_focus_requires_rules(self):
        d=base();d['mode']='focus'
        with self.assertRaises(ValueError):self.norm(d)
    def test_23_focus_has_safety_rules(self):
        d=base();d['mode']='focus';d['review_scope']={'rule_ids':['GN-003'],'pages':[1]}
        r=self.norm(d);self.assertTrue(guardrails.SAFE_RULES<=set(r['review_scope']['rule_ids']))
    def test_24_unknown_inventory_visible(self):
        d=base('確認範囲で適合');r=self.norm(d)
        self.assertFalse(r['summary']['inventory_confirmed']);self.assertIn('未確認',r['summary']['overall'])
    def test_25_empty_normative_registry_blocks_claim(self):
        d=base('確認範囲で適合');d['checks'][0]['basis_type']='規格本文照合'
        with self.assertRaises(ValueError):self.norm(d)
    def test_26_arbitrary_standard_evidence_not_enough(self):
        d=base('確認範囲で適合');d['checks'][0].update(basis_type='規格本文照合',standard_evidence={k:'本文未取得' for k in ['standard','edition','clause','source_file','locator','applicability']})
        with self.assertRaises(ValueError):self.norm(d)
    def test_27_corporate_claim_requires_id(self):
        d=base('確認範囲で適合');d['checks'][0].update(basis_type='社内規則照合',reference='架空の社内標準')
        with self.assertRaises(ValueError):self.norm(d)
    def test_28_expected_region_not_hidden(self):
        d=base();d['expected_coverage']=[{'page':1,'region':'詳細図A'}];r=self.norm(d)
        self.assertGreater(r['summary']['unread_in_requested_scope'],0)
    def test_29_out_of_range_page_rejected(self):
        d=base();d['coverage'][1]['page']=2
        with self.assertRaises(ValueError):self.norm(d)
    def test_30_duplicate_coverage_rejected(self):
        d=base();d['coverage'].append(copy.deepcopy(d['coverage'][0]))
        with self.assertRaises(ValueError):self.norm(d)
    def test_31_corrupt_binding_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'d.txt';p.write_text('different bytes')
            with self.assertRaises(ValueError):report.bind_file(base(),p)
    def test_32_bind_computes_hash(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'d.txt';p.write_text('test');d=base();d['drawing'].pop('sha256')
            self.assertEqual(report.bind_file(d,p)['drawing']['sha256'],hashlib.sha256(b'test').hexdigest())
    def test_33_roundtrip_preserves_guard(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'r.xlsx';r=self.norm(base());report.write_xlsx(r,p);rr=report.read_xlsx(p)
            self.assertEqual(rr['guard_version'],'0.3.0');self.assertEqual(rr['findings'],r['findings'])
    def test_34_recheck_preserves_unresolved(self):
        prev=self.norm(base());d=base();d['mode']='recheck';d['checks']=[];r=report.normalize(d,SKILL,prev)
        self.assertTrue(any(x.get('carry_forward') for x in r['findings']))
    def test_35_same_bytes_not_drawing_change(self):
        prev=self.norm(base());d=base('確認範囲で適合');d['mode']='recheck'
        d['resolutions']=[{'finding_id':prev['findings'][0]['finding_id'],'result':'解消','reason':'架空の修正',
            'source':copy.deepcopy(d['checks'][0]['source']),'resolution_basis':'drawing_change'}]
        with self.assertRaises(ValueError):report.normalize(d,SKILL,prev)
    def test_36_changed_bytes_recheck(self):
        prev=self.norm(base());d=base('確認範囲で適合');d['mode']='recheck';d['drawing']['sha256']='b'*64
        d['resolutions']=[{'finding_id':prev['findings'][0]['finding_id'],'result':'解消','reason':'架空の修正',
            'source':copy.deepcopy(d['checks'][0]['source']),'resolution_basis':'drawing_change'}]
        r=report.normalize(d,SKILL,prev);self.assertEqual(r['recheck'][0]['result'],'解消')


class ApprovalTests(unittest.TestCase):
    def test_37_unapproved_candidate_blocked(self):
        with tempfile.TemporaryDirectory() as t:
            root,d=custom_root(t,False)
            with self.assertRaises(ValueError):report.normalize(d,root)
    def test_38_approved_scoped_candidate_allowed(self):
        with tempfile.TemporaryDirectory() as t:
            root,d=custom_root(t);r=report.normalize(d,root)
            self.assertEqual(r['checks'][0]['status'],'確認範囲で適合')
    def test_39_wrong_product_blocked(self):
        with tempfile.TemporaryDirectory() as t:
            root,d=custom_root(t);d['drawing']['product']='ユニットB'
            with self.assertRaises(ValueError):report.normalize(d,root)
    def test_40_unknown_product_blocked(self):
        with tempfile.TemporaryDirectory() as t:
            root,d=custom_root(t);d['drawing'].pop('product')
            with self.assertRaises(ValueError):report.normalize(d,root)
    def test_41_unverified_condition_blocked(self):
        with tempfile.TemporaryDirectory() as t:
            root,d=custom_root(t);d['checks'][0]['condition_verified']=False
            with self.assertRaises(ValueError):report.normalize(d,root)
    def test_42_stale_catalog_approval_blocked(self):
        with tempfile.TemporaryDirectory() as t:
            root,d=custom_root(t);p=root/'references/rule-catalog.json';c=json.loads(p.read_text());c['package']['version']='9.9';p.write_text(json.dumps(c))
            with self.assertRaises(ValueError):report.normalize(d,root)
    def test_43_expired_approval_blocked(self):
        with tempfile.TemporaryDirectory() as t:
            root,d=custom_root(t);p=root/'references/rule-approvals.json';a=json.loads(p.read_text());a['approved_rules'][0]['valid_until']='2026-10-05';p.write_text(json.dumps(a))
            with self.assertRaises(ValueError):report.normalize(d,root)
    def test_44_normative_link_allowed(self):
        with tempfile.TemporaryDirectory() as t:
            root,d=normative_root(t);r=report.normalize(d,root)
            self.assertIn('SYNTHETIC-CLAUSE',r['checks'][0]['reference'])
    def test_45_metadata_only_blocked(self):
        with tempfile.TemporaryDirectory() as t:
            root,d=normative_root(t);p=root/'references/normative-evidence.json';a=json.loads(p.read_text());a['entries'][0]['content_kind']='metadata_only';p.write_text(json.dumps(a))
            with self.assertRaises(ValueError):report.normalize(d,root)
    def test_46_wrong_normative_rule_blocked(self):
        with tempfile.TemporaryDirectory() as t:
            root,d=normative_root(t);d['targets'][0]['rule_ids']=['DM-003'];d['checks'][0]['rule_id']='DM-003'
            with self.assertRaises(ValueError):report.normalize(d,root)
    def test_47_normative_context_required(self):
        with tempfile.TemporaryDirectory() as t:
            root,d=normative_root(t);d['checks'][0]['exceptions_checked']=False
            with self.assertRaises(ValueError):report.normalize(d,root)
    def test_48_future_approval_blocked(self):
        with tempfile.TemporaryDirectory() as t:
            root,d=normative_root(t);p=root/'references/rule-approvals.json';a=json.loads(p.read_text());a['normative_approvals'][0]['approved_on']='2026-10-07';p.write_text(json.dumps(a))
            with self.assertRaises(ValueError):report.normalize(d,root)

if __name__=='__main__':unittest.main(verbosity=2)
