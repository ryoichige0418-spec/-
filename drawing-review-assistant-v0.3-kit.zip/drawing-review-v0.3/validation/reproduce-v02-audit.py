import sys,json,copy,tempfile
from pathlib import Path
ROOT=Path('./extracted-v02/drawing-review-v0.2/drawing-review-assistant')
sys.path.insert(0,str(ROOT/'scripts'))
import review_report as rr, update_rules as ur
BASE=ROOT.parent
num=json.loads((BASE/'validation/sample-numeric-input.json').read_text())
manifest=json.loads((BASE/'validation/sample-manifest.json').read_text())
def data():
 return {'schema_version':'2.0','review_id':'AUDIT','reviewed_on':'2026-10-06','drawing':copy.deepcopy(num['drawing']),'mode':'all','checks':[],'coverage':[{'page':1,'region':'全体','status':'clear','note':'架空の試験入力'}]}
def check():
 return {'rule_id':'GN-003','target':'title','status':'確認範囲で適合','reason':'テスト','source':{'page':1,'location':'表題欄','raw':'材質 Al'},'basis_type':'一般確認観点','read_status':'確認済み','importance':'中','action':'確認'}
res=[]
d=data();n=copy.deepcopy(num);n['dimensions']=[x for x in n['dimensions'] if x['id'] in {'A','B','T'}];n['fits']=[];d['numeric_input']=n
r=rr.normalize(d,ROOT);res.append({'id':'A01','test':'公差積上げの一部重複が指摘一覧に反映されない','observed':{'classification':r['numeric']['chains'][0]['classification'],'finding_count':r['summary']['finding_count']},'source':'scripts/review_report.py:133-145'})
d=data();d['drawing']['page_count']=3;r=rr.normalize(d,ROOT);res.append({'id':'A02','test':'全3ページに対し1ページだけ記録しても未確認領域0','observed':r['summary']['unread_region_count'],'source':'scripts/review_report.py:117-127,192'})
d=data();d['checks']=[check()];d['coverage'][0]['status']='unreadable';r=rr.normalize(d,ROOT);res.append({'id':'A03','test':'同領域読取り不可と適合が共存','observed':{'status':r['checks'][0]['status'],'coverage':r['coverage'][0]['status']},'source':'scripts/review_report.py:86-95,117-127'})
d=data();c=check();c['source']={'page':None,'location':'未確認','raw':'未取得'};d['checks']=[c];r=rr.normalize(d,ROOT);res.append({'id':'A04','test':'原図の位置・原文が未取得でも適合が通る','observed':r['checks'][0]['status'],'source':'scripts/review_report.py:41-48'})
d=data();c=check();c.update(status=' 指摘あり ');d['checks']=[c];r=rr.normalize(d,ROOT);res.append({'id':'A05','test':'判定前後空白で指摘が集計から落ちる','observed':{'status_counts':r['summary']['status_counts'],'findings':len(r['findings'])},'source':'scripts/review_report.py:81,147-150'})
d=data();c=check();c['basis_type']='規格本文照合';c['reference']='metadata only';c['standard_evidence']={k:'書誌情報のみ・本文未取得' for k in ['standard','edition','clause','source_file','locator','applicability']};d['checks']=[c];r=rr.normalize(d,ROOT);res.append({'id':'A06','test':'本文証拠なしの任意文字列でも規格本文照合が通る','observed':r['checks'][0]['basis_type'],'source':'scripts/review_report.py:94-99'})
initial=json.loads((ROOT/'references/rule-catalog.json').read_text());cat,delta=ur.merge(initial,manifest,'2026-10-06')
res.append({'id':'A07','test':'採用承認記録なしで資料候補がusableになる','observed':{'usable':sum(x['status']=='usable' for x in cat['rules']),'approval_record_present':any('approval' in x for x in cat['rules'])},'source':'scripts/rule_engine.py:217-224; scripts/update_rules.py:44-145'})
with tempfile.TemporaryDirectory() as t:
 import shutil
 target=Path(t)/'skill';shutil.copytree(ROOT,target,ignore=shutil.ignore_patterns('__pycache__'))
 (target/'references/rule-catalog.json').write_text(json.dumps(cat,ensure_ascii=False))
 corp=next(x for x in cat['rules'] if x['status']=='usable')
 d=data();d['drawing']['product']='ユニットB';c=check();c['rule_id']=corp['rule_id'];c['basis_type']='社内規則照合';c['reference']='架空標準';d['checks']=[c]
 r=rr.normalize(d,target);res.append({'id':'A08','test':'社内ルールの適用対象を実行時には照合しない','observed':{'rule_scope':corp['scope']['targets'],'drawing_product':'ユニットB','accepted_status':r['checks'][0]['status']},'source':'scripts/review_report.py:79-99'})
Path('./reproduced-v02-findings.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
print(json.dumps(res,ensure_ascii=False,indent=2))
