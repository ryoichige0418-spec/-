# Agent Builder導入手順

Knowledgeファイルをアップロードできない環境と、添付なしのテーマ起点作成に対応した手順は、次を参照してください。

- `QUICK_START_NO_KNOWLEDGE.md`

作成Agentでは、`Search all websites`が表示される場合はON、`Create documents, charts, and code`はON、ファイルKnowledgeは空欄とします。
