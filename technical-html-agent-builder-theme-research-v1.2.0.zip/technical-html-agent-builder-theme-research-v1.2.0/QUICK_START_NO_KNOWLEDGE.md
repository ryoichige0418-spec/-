# 添付・Knowledgeなしでもテーマから作成する設定手順

## 方針

Knowledgeファイルは使用しません。作成・監査の中核ルールは各`instructions.txt`へ統合済みです。作成Agentは、添付資料がなくても「テーマ起点モード」で調査・構成・HTML生成を開始します。

## 1. 技術HTML資料作成Agent

1. Agent Builderで新しいAgentを作成する。
2. Nameに`技術HTML資料作成`を入力する。
3. `agents/technical-html-author/description.txt`をDescriptionへ貼り付ける。
4. `agents/technical-html-author/instructions.txt`をInstructionsへ全文貼り付ける。
5. ファイルKnowledgeは追加しない。
6. Knowledge欄に`Search all websites`が表示される場合は**ON**にする。
7. `Only use specified sources`は、固定Knowledgeを登録していないため**OFF**にする。
8. People、Email、Teamsは用途がなければOFFにする。
9. `Create documents, charts, and code`をONにする。
10. Default response modeは`Think deeper`を推奨する。
11. `starter_prompts.md`からStarter promptsを登録する。
12. Try itで`test_cases.md`を実行する。

### Web検索が表示されない、または無効な場合

そのまま利用できます。Agentは基礎原理と一般的な技術知識を中心に暫定版を作成し、現在情報、最新動向、規格版、製品仕様などの未検証範囲を明示します。Web検索できない状態で「最新」「現在」を検証済みと表現しないことがInstructionsに組み込まれています。

## 2. 技術HTML品質監査Agent

1. 別の新しいAgentを作成する。
2. Nameに`技術HTML品質監査`を入力する。
3. `agents/technical-html-audit/description.txt`をDescriptionへ貼り付ける。
4. `agents/technical-html-audit/instructions.txt`をInstructionsへ全文貼り付ける。
5. Knowledgeは追加しない。
6. `Create documents, charts, and code`をONにする。
7. `starter_prompts.md`からStarter promptsを登録する。

## 3. 添付なしの使用例

```text
HARCエッチングについて、研究者・プロセス技術者向けの技術資料を作成してください。
原理原則、主要な反応・輸送機構、課題、技術動向、評価指標、今後の論点を含め、
情報基準日と参考文献を示した単一HTMLとして出力してください。
```

```text
COMSOLにおける温度依存物性の強い流体のソルバー選定を、
層流と乱流に分けて解説するHTML資料を作成してください。
添付資料はありません。確認できないバージョン依存事項は未確認と明示してください。
```

## 4. 添付資料がある場合

資料起点モードへ自動的に切り替わります。添付資料を一次情報として扱い、不足部分だけを公開情報で補足します。

## 5. 制約

Knowledgeなしでは、次の組織固有情報は会話ごとに指定します。

- 社内用語辞書
- 社内テンプレート
- 固有の規格・契約資料
- 非公開の設計条件

Web検索の利用可否は、テナントのライセンスと管理ポリシーに依存します。Web検索が利用できない場合でも資料生成は継続しますが、最新性の保証範囲は限定されます。
