# Validation Report

Package version: 1.2.0  
Validation date: 2026-08-06

## Result

PASS: Agent Builder theme-first package validation passed.

## Agent Builder field limits

| Agent | Name chars / 30 | Description chars / 1000 | Instructions chars / 8000 | File Knowledge | Starter prompts | Tests |
|---|---:|---:|---:|---:|---:|---:|
| technical-html-author | 10 | 147 | 2,876 | 0 | 8 | 8 |
| technical-html-audit | 10 | 111 | 2,716 | 0 | 7 | 6 |

Character counts are Unicode code points excluding the trailing newline in the Name field.

## Behavior checks

- PASS: Attachment-free requests invoke a dedicated theme-first workflow.
- PASS: Missing audience, purpose, and scope are completed as explicit assumptions.
- PASS: Current or unstable topics invoke Web search when available.
- PASS: Web-unavailable mode still produces a provisional document and exposes unverified scope.
- PASS: Primary and official sources are prioritized.
- PASS: Japanese and English search terms and multi-source comparison are specified.
- PASS: Publication date and technical-event or revision date are distinguished.
- PASS: Fabricated publications, DOI, URL, quotations, and standard numbers are prohibited.
- PASS: “Latest” and “current” claims require verification.
- PASS: Theme-first, source-first, and revision modes are separated.
- PASS: Code Interpreter file generation and static HTML checks remain included.
- PASS: Original-file preservation and prompt-injection resistance remain included.
- PASS: Audit Agent checks source existence and recency when Web access is available.
- PASS: Browser, keyboard, screen-reader, and print checks are not falsely claimed when unexecuted.

## Package checks

- PASS: All files referenced by the setup guide exist.
- PASS: Both `name.txt`, `description.txt`, `instructions.txt`, `starter_prompts.md`, and `test_cases.md` sets exist.
- PASS: Instructions remain below Agent Builder's 8,000-character limit.
- PASS: No embedded Knowledge file is required.

## Known limitations

- Agent Builder has no direct ZIP import; fields must be copied into Configure.
- `Search all websites` availability depends on tenant licensing, UI exposure, and administrator policy.
- If Web search is blocked, current trends, standards revisions, product specifications, and software versions cannot be verified automatically.
- Code Interpreter static analysis is not equivalent to deterministic CI or Playwright browser QA.
- Final behavior should be retested after Microsoft model or Agent Builder updates.
