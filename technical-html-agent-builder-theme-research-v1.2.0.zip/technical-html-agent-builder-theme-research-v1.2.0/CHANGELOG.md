# Changelog

## v1.2.0 — 2026-08-06

- Added topic-first technical research workflow without attachments.
- Added web-available and web-unavailable operating modes.
- Added source hierarchy, recency checks, evidence classification, and citation requirements.
- Replaced attachment-centered starter prompts with eight mixed-mode prompts.
- Added eight author Try it test cases.
- Updated no-Knowledge setup instructions.
