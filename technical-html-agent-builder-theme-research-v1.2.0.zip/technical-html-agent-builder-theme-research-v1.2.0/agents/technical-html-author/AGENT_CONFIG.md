# Agent Builder設定票：技術HTML資料作成

| 項目 | 設定 |
|---|---|
| Name | `技術HTML資料作成` |
| Description | `description.txt`全文 |
| Instructions | `instructions.txt`全文 |
| File Knowledge | 追加しない |
| Search all websites | 表示される場合はON |
| Only use specified sources | OFF |
| People／Email／Teams | 通常はOFF |
| Create documents, charts, and code | ON |
| Create images | 任意。基本はOFF |
| Default response mode | `Think deeper`推奨 |
| Starter prompts | `starter_prompts.md`の8件 |

## 主要動作

- 添付なし：テーマ起点モード
- 添付あり：資料起点モード
- 既存HTML：改訂モード
- Web検索不可：暫定版を生成し、未検証範囲を表示
