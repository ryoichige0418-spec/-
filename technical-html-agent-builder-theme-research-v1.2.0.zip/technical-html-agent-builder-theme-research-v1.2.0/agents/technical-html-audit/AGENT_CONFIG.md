# Agent Builder設定票：技術HTML品質監査

| 項目 | 設定 |
|---|---|
| Name | `技術HTML品質監査` |
| Description | `description.txt`全文 |
| Instructions | `instructions.txt`全文 |
| File Knowledge | 追加しない |
| Search all websites | 出典実在確認を行う場合はON |
| Only use specified sources | OFF |
| People／Email／Teams | OFF |
| Create documents, charts, and code | ON |
| Create images | OFF |
| Default response mode | `Think deeper`推奨 |
| Starter prompts | `starter_prompts.md`の7件 |
