# 技術HTML Agent Builder テーマ起点対応版 v1.2.0

Microsoft 365 Copilot Agent BuilderでKnowledgeファイルをアップロードできない環境向けです。添付資料がなくても、指定テーマから技術調査とHTML資料作成を開始できます。

## 主な変更

- 作成Agentへ「テーマ起点モード」を追加
- 添付なしでも対象読者、範囲、調査問いを補完
- Web検索利用時の一次資料優先・出典照合ワークフローを追加
- Web検索不可時の暫定版作成と未検証表示を追加
- 技術動向、原理解説、方式比較、実務手順のStarter promptsを追加
- 添付なし、検索不可、出典捏造防止を含むTry itテストを追加
- Knowledge欄は空のまま利用可能

最初に`QUICK_START_NO_KNOWLEDGE.md`を参照してください。
